import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import type {
  Order,
  Product,
  Category,
  InventoryItem,
  InventoryMovement,
  CashRegister,
  CashMovement,
  Expense,
  Customer,
  Coupon,
  Courier,
  Supplier,
  UserAccount,
  RestaurantSettings,
  SystemNotification,
  SystemAuditLog,
  OrderStatus
} from './src/types/index.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'lanchonete_db.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

interface DatabaseSchema {
  categories: Category[];
  products: Product[];
  inventory: InventoryItem[];
  inventoryMovements: InventoryMovement[];
  orders: Order[];
  cashRegisters: CashRegister[];
  cashMovements: CashMovement[];
  expenses: Expense[];
  customers: Customer[];
  coupons: Coupon[];
  couriers: Courier[];
  suppliers: Supplier[];
  users: UserAccount[];
  settings: RestaurantSettings;
  notifications: SystemNotification[];
  auditLogs: SystemAuditLog[];
}

function getInitialDatabase(): DatabaseSchema {
  const categories: Category[] = [
    { id: 'cat-1', name: 'Hambúrgueres Artesanais', slug: 'hamburgueres', order: 1, active: true },
    { id: 'cat-2', name: 'Combos & Promoções', slug: 'combos', order: 2, active: true },
    { id: 'cat-3', name: 'Batatas & Acompanhamentos', slug: 'porcoes', order: 3, active: true },
    { id: 'cat-4', name: 'Cachorros-Quentes Gourmet', slug: 'hot-dogs', order: 4, active: true },
    { id: 'cat-5', name: 'Bebidas & Shakes', slug: 'bebidas', order: 5, active: true },
    { id: 'cat-6', name: 'Sobremesas', slug: 'sobremesas', order: 6, active: true },
  ];

  const inventory: InventoryItem[] = [
    { id: 'inv-1', code: 'ING-001', name: 'Pão de Brioche Selado', category: 'Pães', unit: 'un', currentQuantity: 120, reservedQuantity: 6, minQuantity: 30, unitCost: 1.80, supplierId: 'sup-1', supplierName: 'Panificadora Central', expirationDate: '2026-10-18', lotNumber: 'L-202610-01', storageLocation: 'Despensa Seca' },
    { id: 'inv-2', code: 'ING-002', name: 'Blend Bovino Angus (160g)', category: 'Carnes', unit: 'un', currentQuantity: 95, reservedQuantity: 6, minQuantity: 25, unitCost: 5.50, supplierId: 'sup-2', supplierName: 'Frigorífico Premium Carnes', expirationDate: '2026-10-22', lotNumber: 'L-202610-04', storageLocation: 'Câmara Fria 1' },
    { id: 'inv-3', code: 'ING-003', name: 'Queijo Cheddar Inglês Fatiado', category: 'Laticínios', unit: 'kg', currentQuantity: 12.5, reservedQuantity: 0.8, minQuantity: 3.0, unitCost: 42.00, supplierId: 'sup-3', supplierName: 'Distribuidora Laticínios Vale', expirationDate: '2026-11-15', lotNumber: 'L-202610-12', storageLocation: 'Câmara Fria 2' },
    { id: 'inv-4', code: 'ING-004', name: 'Bacon Defumado Artesanal em Tiras', category: 'Carnes', unit: 'kg', currentQuantity: 8.2, reservedQuantity: 0.5, minQuantity: 2.5, unitCost: 38.00, supplierId: 'sup-2', supplierName: 'Frigorífico Premium Carnes', expirationDate: '2026-11-05', lotNumber: 'L-202610-08', storageLocation: 'Câmara Fria 2' },
    { id: 'inv-5', code: 'ING-005', name: 'Batata Palito Importada Congelada', category: 'Congelados', unit: 'kg', currentQuantity: 45.0, reservedQuantity: 2.0, minQuantity: 15.0, unitCost: 12.50, supplierId: 'sup-4', supplierName: 'FoodService Brasil Atacado', expirationDate: '2027-02-10', lotNumber: 'L-202609-88', storageLocation: 'Freezer Principal' },
    { id: 'inv-6', code: 'ING-006', name: 'Maionese Especial da Casa Trufada', category: 'Molhos', unit: 'kg', currentQuantity: 6.0, reservedQuantity: 0.3, minQuantity: 2.0, unitCost: 18.00, supplierId: 'sup-4', supplierName: 'FoodService Brasil Atacado', expirationDate: '2026-10-25', lotNumber: 'L-202610-15', storageLocation: 'Câmara Fria 2' },
    { id: 'inv-7', code: 'ING-007', name: 'Salsicha Defumada Especial Tipo Frankfurt', category: 'Carnes', unit: 'un', currentQuantity: 40, reservedQuantity: 2, minQuantity: 15, unitCost: 2.40, supplierId: 'sup-2', supplierName: 'Frigorífico Premium Carnes', expirationDate: '2026-10-28', lotNumber: 'L-202610-09', storageLocation: 'Câmara Fria 1' },
    { id: 'inv-8', code: 'ING-008', name: 'Batata Palha Crocante Extra Fina', category: 'Secos', unit: 'kg', currentQuantity: 7.0, reservedQuantity: 0.2, minQuantity: 2.0, unitCost: 22.00, supplierId: 'sup-4', supplierName: 'FoodService Brasil Atacado', expirationDate: '2026-12-30', lotNumber: 'L-202610-03', storageLocation: 'Despensa Seca' },
    { id: 'inv-9', code: 'ING-009', name: 'Sorvete de Chocolate Belga', category: 'Sobremesas', unit: 'l', currentQuantity: 18.0, reservedQuantity: 1.0, minQuantity: 5.0, unitCost: 28.00, supplierId: 'sup-3', supplierName: 'Distribuidora Laticínios Vale', expirationDate: '2027-01-10', lotNumber: 'L-202610-20', storageLocation: 'Freezer Sobremesas' },
    { id: 'inv-10', code: 'ING-010', name: 'Embalagem Kraft Térmica Premium', category: 'Embalagens', unit: 'un', currentQuantity: 180, reservedQuantity: 8, minQuantity: 50, unitCost: 1.20, supplierId: 'sup-5', supplierName: 'PackFood Embalagens', expirationDate: '2028-01-01', lotNumber: 'L-202608-01', storageLocation: 'Depósito Embalagens' },
    { id: 'inv-11', code: 'ING-011', name: 'Refrigerante Coca-Cola Lata 350ml', category: 'Bebidas', unit: 'un', currentQuantity: 8, reservedQuantity: 0, minQuantity: 24, unitCost: 2.80, supplierId: 'sup-4', supplierName: 'FoodService Brasil Atacado', expirationDate: '2027-04-15', lotNumber: 'L-202610-33', storageLocation: 'Geladeira Bebidas' },
    { id: 'inv-12', code: 'ING-012', name: 'Cerveja Artesanal IPA 500ml', category: 'Bebidas', unit: 'un', currentQuantity: 32, reservedQuantity: 0, minQuantity: 12, unitCost: 8.50, supplierId: 'sup-6', supplierName: 'Cervejaria Hop Craft', expirationDate: '2026-12-01', lotNumber: 'L-202610-40', storageLocation: 'Geladeira Bebidas' },
  ];

  const products: Product[] = [
    {
      id: 'prod-1',
      code: 'BUR-01',
      name: 'Smash Burger Clássico Duplo',
      description: 'Dois burgers bovinos angus de 160g smashados, generoso cheddar derretido, tiras de bacon crocante e cebola caramelizada no pão brioche amanteigado.',
      price: 36.90,
      costPrice: 12.40,
      categoryId: 'cat-1',
      imageUrl: '/src/assets/images/burger_artesanal_1791633585054.jpg',
      available: true,
      featured: true,
      prepTimeMinutes: 14,
      ingredients: [
        { inventoryItemId: 'inv-1', name: 'Pão de Brioche Selado', quantity: 1, unit: 'un' },
        { inventoryItemId: 'inv-2', name: 'Blend Bovino Angus (160g)', quantity: 2, unit: 'un' },
        { inventoryItemId: 'inv-3', name: 'Queijo Cheddar Inglês', quantity: 0.05, unit: 'kg' },
        { inventoryItemId: 'inv-4', name: 'Bacon Defumado em Tiras', quantity: 0.04, unit: 'kg' },
        { inventoryItemId: 'inv-10', name: 'Embalagem Kraft', quantity: 1, unit: 'un' }
      ],
      addOns: [
        { id: 'add-1', name: 'Bacon Crocante Extra', price: 6.00 },
        { id: 'add-2', name: 'Cheddar Inglês Duplo', price: 5.00 },
        { id: 'add-3', name: 'Blend Angus Extra (160g)', price: 10.00 },
        { id: 'add-4', name: 'Maionese Trufada da Casa (50g)', price: 4.50 },
        { id: 'add-5', name: 'Ovo Frito na Manteiga', price: 3.50 }
      ],
      removableIngredients: ['Cebola Caramelizada', 'Bacon', 'Picles', 'Molho']
    },
    {
      id: 'prod-2',
      code: 'BUR-02',
      name: 'Combo Burger Smash + Batata Rústica + Refri',
      description: 'O nosso campeão de vendas! Smash Burger Duplo completo acompanhado de porção generosa de batata rústica com molho especial e Coca-Cola gelada.',
      price: 49.90,
      costPrice: 17.20,
      categoryId: 'cat-2',
      imageUrl: '/src/assets/images/lanchonete_hero_banner_1791633574513.jpg',
      available: true,
      featured: true,
      prepTimeMinutes: 16,
      ingredients: [
        { inventoryItemId: 'inv-1', name: 'Pão de Brioche', quantity: 1, unit: 'un' },
        { inventoryItemId: 'inv-2', name: 'Blend Bovino Angus', quantity: 2, unit: 'un' },
        { inventoryItemId: 'inv-3', name: 'Queijo Cheddar', quantity: 0.05, unit: 'kg' },
        { inventoryItemId: 'inv-5', name: 'Batata Palito Congelada', quantity: 0.20, unit: 'kg' },
        { inventoryItemId: 'inv-11', name: 'Coca-Cola Lata', quantity: 1, unit: 'un' },
        { inventoryItemId: 'inv-10', name: 'Embalagem Kraft', quantity: 2, unit: 'un' }
      ],
      addOns: [
        { id: 'add-1', name: 'Turbinar com Bacon no Burger', price: 6.00 },
        { id: 'add-2', name: 'Cheddar Cremoso na Batata', price: 7.00 },
        { id: 'add-4', name: 'Maionese Trufada Extra', price: 4.50 }
      ],
      removableIngredients: ['Cebola Caramelizada', 'Bacon']
    },
    {
      id: 'prod-3',
      code: 'POR-01',
      name: 'Batata Rústica Crocante com Molhos',
      description: 'Batatas selecionadas crocantes por fora e macias por dentro, salpicadas com páprica defumada e servidas com maionese artesanal e molho chipotle.',
      price: 24.90,
      costPrice: 6.50,
      categoryId: 'cat-3',
      imageUrl: '/src/assets/images/french_fries_combo_1791633594665.jpg',
      available: true,
      featured: false,
      prepTimeMinutes: 10,
      ingredients: [
        { inventoryItemId: 'inv-5', name: 'Batata Congelada', quantity: 0.35, unit: 'kg' },
        { inventoryItemId: 'inv-6', name: 'Maionese Especial', quantity: 0.06, unit: 'kg' },
        { inventoryItemId: 'inv-10', name: 'Embalagem Kraft', quantity: 1, unit: 'un' }
      ],
      addOns: [
        { id: 'add-por-1', name: 'Cheddar Cremoso e Farofa de Bacon', price: 8.50 },
        { id: 'add-por-2', name: 'Molho Alho Poró Extra', price: 4.00 }
      ],
      removableIngredients: ['Páprica Defumada', 'Sal']
    },
    {
      id: 'prod-4',
      code: 'HOT-01',
      name: 'Hot Dog Prensado Supremo',
      description: 'Pão artesanal tostado, salsicha Frankfurt defumada grelhada, purê de batata amanteigado, milho doce, queijo derretido e batata palha extra crocante.',
      price: 26.50,
      costPrice: 7.90,
      categoryId: 'cat-4',
      imageUrl: '/src/assets/images/hot_dog_especial_1791633603513.jpg',
      available: true,
      featured: false,
      prepTimeMinutes: 12,
      ingredients: [
        { inventoryItemId: 'inv-7', name: 'Salsicha Defumada Especial', quantity: 1, unit: 'un' },
        { inventoryItemId: 'inv-8', name: 'Batata Palha Crocante', quantity: 0.05, unit: 'kg' },
        { inventoryItemId: 'inv-3', name: 'Queijo Cheddar', quantity: 0.03, unit: 'kg' },
        { inventoryItemId: 'inv-10', name: 'Embalagem Kraft', quantity: 1, unit: 'un' }
      ],
      addOns: [
        { id: 'add-hot-1', name: 'Salsicha Extra Frankfurt', price: 5.00 },
        { id: 'add-hot-2', name: 'Bacon em Cubos', price: 5.50 },
        { id: 'add-hot-3', name: 'Catupiry Original', price: 5.00 }
      ],
      removableIngredients: ['Milho Doce', 'Batata Palha', 'Molho de Tomate']
    },
    {
      id: 'prod-5',
      code: 'BEB-01',
      name: 'Milkshake Gourmet de Chocolate Belga',
      description: 'Delicioso milkshake batido com sorvete de chocolate belga nobre, chantilly fresco artesanal, calda quente de cacau e waffle crocante.',
      price: 23.00,
      costPrice: 7.10,
      categoryId: 'cat-5',
      imageUrl: '/src/assets/images/milkshake_artesanal_1791633612819.jpg',
      available: true,
      featured: true,
      prepTimeMinutes: 8,
      ingredients: [
        { inventoryItemId: 'inv-9', name: 'Sorvete de Chocolate Belga', quantity: 0.25, unit: 'l' },
        { inventoryItemId: 'inv-10', name: 'Embalagem Kraft / Copo Shake', quantity: 1, unit: 'un' }
      ],
      addOns: [
        { id: 'add-shk-1', name: 'Dose Extra de Calda de Avelã', price: 4.00 },
        { id: 'add-shk-2', name: 'Raspas de Chocolate Nobre', price: 3.50 }
      ],
      removableIngredients: ['Chantilly', 'Waffle']
    },
    {
      id: 'prod-6',
      code: 'BEB-02',
      name: 'Coca-Cola Original 350ml Lata',
      description: 'Refrigerante Coca-Cola em lata 350ml estupidamente gelada.',
      price: 6.50,
      costPrice: 2.80,
      categoryId: 'cat-5',
      imageUrl: '/src/assets/images/lanchonete_hero_banner_1791633574513.jpg',
      available: false, // low inventory demonstration
      featured: false,
      prepTimeMinutes: 2,
      ingredients: [
        { inventoryItemId: 'inv-11', name: 'Coca-Cola Lata 350ml', quantity: 1, unit: 'un' }
      ],
      addOns: [],
      removableIngredients: []
    }
  ];

  const now = new Date();
  const isoNow = now.toISOString();
  const formatTime = (minutesAgo: number) => {
    const d = new Date(now.getTime() - minutesAgo * 60000);
    return d.toISOString();
  };

  const orders: Order[] = [
    {
      id: 'ord-1001',
      orderNumber: 1001,
      customerName: 'Lucas Ferreira',
      customerPhone: '(11) 98765-4321',
      customerAddress: {
        street: 'Rua das Flores',
        number: '240',
        neighborhood: 'Jardins',
        complement: 'Apto 42',
        reference: 'Próximo à padaria',
        city: 'São Paulo'
      },
      orderType: 'delivery',
      status: 'saiu_entrega',
      items: [
        {
          id: 'item-1',
          productId: 'prod-2',
          productName: 'Combo Burger Smash + Batata Rústica + Refri',
          quantity: 1,
          unitPrice: 49.90,
          addOns: [{ id: 'add-1', name: 'Turbinar com Bacon no Burger', price: 6.00 }],
          notes: 'Ponto da carne ao ponto para bem passado, por favor.',
          totalPrice: 55.90
        },
        {
          id: 'item-2',
          productId: 'prod-5',
          productName: 'Milkshake Gourmet de Chocolate Belga',
          quantity: 1,
          unitPrice: 23.00,
          addOns: [],
          totalPrice: 23.00
        }
      ],
      subtotal: 78.90,
      deliveryFee: 8.00,
      discount: 0,
      total: 86.90,
      paymentMethod: 'pix',
      paymentStatus: 'pago',
      estimatedPrepMinutes: 20,
      courierId: 'cour-1',
      courierName: 'Carlos Entregador (Moto)',
      createdAt: formatTime(35),
      updatedAt: formatTime(5),
      statusHistory: [
        { status: 'recebido', timestamp: formatTime(35), updatedBy: 'Cliente via Web' },
        { status: 'confirmado', timestamp: formatTime(32), updatedBy: 'Sistema Automático' },
        { status: 'em_preparacao', timestamp: formatTime(28), updatedBy: 'Cozinha - Chefe Roberto' },
        { status: 'pronto', timestamp: formatTime(10), updatedBy: 'Cozinha - Chefe Roberto' },
        { status: 'saiu_entrega', timestamp: formatTime(5), updatedBy: 'Expedição Balcão' }
      ],
      communicationLog: [
        { id: 'com-1', channel: 'app', message: 'Recebemos seu pedido! Estamos verificando os detalhes e logo iniciaremos a preparação.', status: 'sent', timestamp: formatTime(35) },
        { id: 'com-2', channel: 'app', message: '🍔 SEU PEDIDO ESTÁ SENDO PREPARADO! Nossa equipe já começou a preparar tudo com muito carinho.', status: 'sent', timestamp: formatTime(28) },
        { id: 'com-3', channel: 'whatsapp', message: '🛵 Seu pedido saiu para entrega com Carlos Entregador! Em breve ele chegará até você.', status: 'sent', timestamp: formatTime(5) }
      ],
      stockStatus: 'deducted'
    },
    {
      id: 'ord-1002',
      orderNumber: 1002,
      customerName: 'Mariana Duarte',
      customerPhone: '(11) 97722-1133',
      orderType: 'mesa',
      tableNumber: 'Mesa 04',
      status: 'em_preparacao',
      items: [
        {
          id: 'item-3',
          productId: 'prod-1',
          productName: 'Smash Burger Clássico Duplo',
          quantity: 2,
          unitPrice: 36.90,
          addOns: [{ id: 'add-2', name: 'Cheddar Inglês Duplo', price: 5.00 }],
          removedIngredients: ['Picles'],
          notes: 'Sem picles em um dos lanches.',
          totalPrice: 78.80
        },
        {
          id: 'item-4',
          productId: 'prod-3',
          productName: 'Batata Rústica Crocante com Molhos',
          quantity: 1,
          unitPrice: 24.90,
          addOns: [{ id: 'add-por-1', name: 'Cheddar Cremoso e Farofa de Bacon', price: 8.50 }],
          totalPrice: 33.40
        }
      ],
      subtotal: 112.20,
      deliveryFee: 0,
      discount: 10.00,
      couponCode: 'BEMVINDO10',
      total: 102.20,
      paymentMethod: 'cartao_credito',
      paymentStatus: 'pago',
      estimatedPrepMinutes: 18,
      createdAt: formatTime(15),
      updatedAt: formatTime(12),
      statusHistory: [
        { status: 'recebido', timestamp: formatTime(15), updatedBy: 'Atendente Juliana' },
        { status: 'confirmado', timestamp: formatTime(14), updatedBy: 'Atendente Juliana' },
        { status: 'em_preparacao', timestamp: formatTime(12), updatedBy: 'Cozinha - Chapa 1' }
      ],
      communicationLog: [
        { id: 'com-4', channel: 'app', message: 'Seu pedido foi confirmado! Já estamos organizando tudo para preparar sua refeição.', status: 'sent', timestamp: formatTime(14) }
      ],
      stockStatus: 'reserved'
    },
    {
      id: 'ord-1003',
      orderNumber: 1003,
      customerName: 'Rodrigo Santoro',
      customerPhone: '(11) 99112-9844',
      orderType: 'retirada',
      status: 'pronto',
      items: [
        {
          id: 'item-5',
          productId: 'prod-4',
          productName: 'Hot Dog Prensado Supremo',
          quantity: 2,
          unitPrice: 26.50,
          addOns: [{ id: 'add-hot-2', name: 'Bacon em Cubos', price: 5.50 }],
          totalPrice: 64.00
        }
      ],
      subtotal: 64.00,
      deliveryFee: 0,
      discount: 0,
      total: 64.00,
      paymentMethod: 'dinheiro',
      paymentStatus: 'pago',
      changeFor: 100.00,
      estimatedPrepMinutes: 12,
      createdAt: formatTime(25),
      updatedAt: formatTime(3),
      statusHistory: [
        { status: 'recebido', timestamp: formatTime(25), updatedBy: 'PDV Balcão' },
        { status: 'confirmado', timestamp: formatTime(24), updatedBy: 'PDV Balcão' },
        { status: 'em_preparacao', timestamp: formatTime(20), updatedBy: 'Cozinha - Montagem' },
        { status: 'pronto', timestamp: formatTime(3), updatedBy: 'Cozinha - Montagem' }
      ],
      communicationLog: [
        { id: 'com-5', channel: 'app', message: '✅ Seu pedido está pronto! Você já pode retirar no balcão chamando pela Senha #1003.', status: 'sent', timestamp: formatTime(3) }
      ],
      stockStatus: 'deducted'
    },
    {
      id: 'ord-1004',
      orderNumber: 1004,
      customerName: 'Beatriz Lima',
      customerPhone: '(11) 98114-5566',
      customerAddress: {
        street: 'Av. Paulista',
        number: '1200',
        neighborhood: 'Bela Vista',
        complement: 'Conjunto 81',
        city: 'São Paulo'
      },
      orderType: 'delivery',
      status: 'aguardando_confirmacao',
      items: [
        {
          id: 'item-6',
          productId: 'prod-1',
          productName: 'Smash Burger Clássico Duplo',
          quantity: 1,
          unitPrice: 36.90,
          addOns: [],
          notes: 'Por favor, caprichar na cebola caramelizada.',
          totalPrice: 36.90
        }
      ],
      subtotal: 36.90,
      deliveryFee: 7.00,
      discount: 0,
      total: 43.90,
      paymentMethod: 'pix',
      paymentStatus: 'pago',
      estimatedPrepMinutes: 15,
      createdAt: formatTime(2),
      updatedAt: formatTime(2),
      statusHistory: [
        { status: 'recebido', timestamp: formatTime(2), updatedBy: 'Cliente via Web' },
        { status: 'aguardando_confirmacao', timestamp: formatTime(2), updatedBy: 'Sistema' }
      ],
      communicationLog: [
        { id: 'com-6', channel: 'app', message: 'Recebemos seu pedido! Estamos verificando os detalhes e logo iniciaremos a preparação.', status: 'sent', timestamp: formatTime(2) }
      ],
      stockStatus: 'none'
    }
  ];

  const cashRegisters: CashRegister[] = [
    {
      id: 'cx-001',
      openedAt: formatTime(360),
      openedBy: 'Gabriel Caixa',
      initialCash: 150.00,
      currentCash: 314.00,
      salesCash: 64.00,
      salesCard: 102.20,
      salesPix: 130.80,
      totalSales: 297.00,
      sangrias: 0,
      suprimentos: 100.00,
      status: 'open',
      notes: 'Turno diário iniciado com troco conferido.'
    }
  ];

  const cashMovements: CashMovement[] = [
    {
      id: 'mov-1',
      cashRegisterId: 'cx-001',
      type: 'suprimento',
      amount: 100.00,
      reason: 'Reforço de moedas e cédulas de 2 e 5 reais para troco',
      timestamp: formatTime(300),
      operator: 'Gabriel Caixa'
    }
  ];

  const expenses: Expense[] = [
    { id: 'exp-1', description: 'Conta de Energia Elétrica - Enel', category: 'fixa', amount: 840.50, dueDate: '2026-10-15', status: 'pendente' },
    { id: 'exp-2', description: 'Compra Semanal de Carnes Angus', category: 'ingredientes', amount: 1450.00, dueDate: '2026-10-08', paidDate: '2026-10-08', status: 'pago', supplierId: 'sup-2' },
    { id: 'exp-3', description: 'Gás GLP Industrial (2x P45)', category: 'fixa', amount: 480.00, dueDate: '2026-10-05', paidDate: '2026-10-05', status: 'pago' },
    { id: 'exp-4', description: 'Taxas Maquininhas Stone / Cielo', category: 'taxas', amount: 215.30, dueDate: '2026-10-10', status: 'pendente' },
  ];

  const customers: Customer[] = [
    {
      id: 'cust-1',
      name: 'Lucas Ferreira',
      phone: '(11) 98765-4321',
      email: 'lucas.ferreira@email.com',
      addresses: [{ street: 'Rua das Flores', number: '240', neighborhood: 'Jardins', complement: 'Apto 42' }],
      ordersCount: 8,
      totalSpent: 412.50,
      points: 82,
      createdAt: '2026-06-12T10:00:00Z',
      lastOrderDate: formatTime(35)
    },
    {
      id: 'cust-2',
      name: 'Mariana Duarte',
      phone: '(11) 97722-1133',
      email: 'mariana.d@email.com',
      addresses: [],
      ordersCount: 5,
      totalSpent: 320.00,
      points: 64,
      createdAt: '2026-07-20T14:30:00Z',
      lastOrderDate: formatTime(15)
    },
    {
      id: 'cust-3',
      name: 'Rodrigo Santoro',
      phone: '(11) 99112-9844',
      email: 'rodrigo.s@email.com',
      addresses: [],
      ordersCount: 3,
      totalSpent: 180.00,
      points: 36,
      createdAt: '2026-08-01T19:00:00Z',
      lastOrderDate: formatTime(25)
    },
    {
      id: 'cust-4',
      name: 'Beatriz Lima',
      phone: '(11) 98114-5566',
      email: 'beatriz.lima@email.com',
      addresses: [{ street: 'Av. Paulista', number: '1200', neighborhood: 'Bela Vista' }],
      ordersCount: 1,
      totalSpent: 43.90,
      points: 8,
      createdAt: isoNow,
      lastOrderDate: formatTime(2)
    }
  ];

  const coupons: Coupon[] = [
    { id: 'coup-1', code: 'BEMVINDO10', discountType: 'fixed', value: 10.00, minOrderValue: 40.00, active: true, validUntil: '2026-12-31', usageCount: 28 },
    { id: 'coup-2', code: 'SMASH15', discountType: 'percentage', value: 15, minOrderValue: 60.00, active: true, validUntil: '2026-11-30', usageCount: 14 },
    { id: 'coup-3', code: 'FRETEGRATIS', discountType: 'fixed', value: 8.00, minOrderValue: 50.00, active: true, validUntil: '2026-10-31', usageCount: 42 }
  ];

  const couriers: Courier[] = [
    { id: 'cour-1', name: 'Carlos Entregador (Moto)', phone: '(11) 99881-2233', vehicle: 'moto', plate: 'ABC-1D23', active: true, currentDeliveriesCount: 1 },
    { id: 'cour-2', name: 'Felipe Santos (Bicicleta)', phone: '(11) 99443-8877', vehicle: 'bicicleta', active: true, currentDeliveriesCount: 0 },
    { id: 'cour-3', name: 'Marcos Oliveira (Moto)', phone: '(11) 98221-5544', vehicle: 'moto', plate: 'DEF-4E56', active: true, currentDeliveriesCount: 0 }
  ];

  const suppliers: Supplier[] = [
    { id: 'sup-1', name: 'Panificadora Central', contactPerson: 'Seu Mário', phone: '(11) 3221-9988', email: 'vendas@panicentral.com.br', cnpj: '12.345.678/0001-90', itemsSupplied: ['Pão de Brioche', 'Pão Australiano'] },
    { id: 'sup-2', name: 'Frigorífico Premium Carnes', contactPerson: 'Valdemar', phone: '(11) 3344-5566', email: 'contato@carnespremium.com.br', cnpj: '98.765.432/0001-11', itemsSupplied: ['Blend Angus', 'Bacon Artesanal', 'Salsicha Frankfurt'] },
    { id: 'sup-3', name: 'Distribuidora Laticínios Vale', contactPerson: 'Cláudia', phone: '(11) 3105-4422', email: 'pedidos@laticiniosvale.com.br', cnpj: '44.555.666/0001-22', itemsSupplied: ['Cheddar Inglês', 'Muçarela', 'Sorvetes'] },
    { id: 'sup-4', name: 'FoodService Brasil Atacado', contactPerson: 'Leandro', phone: '(11) 3999-1100', email: 'atacado@foodservicebr.com', cnpj: '33.222.111/0001-88', itemsSupplied: ['Batata Palito', 'Maionese', 'Refrigerantes'] },
    { id: 'sup-5', name: 'PackFood Embalagens', contactPerson: 'Fernanda', phone: '(11) 3456-7890', email: 'contato@packfood.com.br', cnpj: '55.666.777/0001-33', itemsSupplied: ['Embalagens Kraft', 'Copos Térmicos', 'Sacolas'] },
    { id: 'sup-6', name: 'Cervejaria Hop Craft', contactPerson: 'Bruno Cervejeiro', phone: '(11) 3667-8899', email: 'vendas@hopcraft.com.br', cnpj: '77.888.999/0001-44', itemsSupplied: ['Cervejas Artesanais'] }
  ];

  const users: UserAccount[] = [
    { id: 'usr-1', name: 'Administrador Geral', email: 'admin@burgerflow.com', role: 'admin', pin: '1234', active: true },
    { id: 'usr-2', name: 'Juliana Gerente', email: 'juliana@burgerflow.com', role: 'gerente', pin: '4321', active: true },
    { id: 'usr-3', name: 'Gabriel Caixa', email: 'gabriel@burgerflow.com', role: 'caixa', pin: '1111', active: true },
    { id: 'usr-4', name: 'Roberto Cozinha', email: 'roberto@burgerflow.com', role: 'cozinha', pin: '2222', active: true },
    { id: 'usr-5', name: 'Tatiana Atendente', email: 'tatiana@burgerflow.com', role: 'atendente', pin: '3333', active: true }
  ];

  const settings: RestaurantSettings = {
    restaurantName: 'Burger & Co. Artesanal',
    tradeName: 'Burger & Co. Lanchonete e Hamburgueria',
    cnpj: '45.123.789/0001-50',
    phone: '(11) 3210-9876',
    whatsapp: '5511987654321',
    address: 'Rua Augusta, 1420 - Consolação',
    city: 'São Paulo',
    state: 'SP',
    isOpen: true,
    openingHoursDescription: 'Segunda a Domingo das 11:30 às 23:30',
    standardDeliveryFee: 7.00,
    freeDeliveryThreshold: 90.00,
    minOrderValue: 20.00,
    averagePrepTimeMinutes: 20,
    deliveryNeighborhoods: [
      { name: 'Consolação', fee: 5.00, estimatedMinutes: 20 },
      { name: 'Bela Vista', fee: 7.00, estimatedMinutes: 25 },
      { name: 'Jardins', fee: 8.00, estimatedMinutes: 30 },
      { name: 'Higienópolis', fee: 7.00, estimatedMinutes: 25 },
      { name: 'Pinheiros', fee: 10.00, estimatedMinutes: 35 },
      { name: 'Vila Buarque', fee: 6.00, estimatedMinutes: 22 }
    ],
    automatedMessages: {
      recebido: 'Recebemos seu pedido! Estamos verificando os detalhes e logo iniciaremos a preparação.',
      aguardando_confirmacao: 'Aguardando confirmação da lanchonete.',
      confirmado: 'Seu pedido foi confirmado! Já estamos organizando tudo para preparar sua refeição.',
      em_preparacao: '🍔 SEU PEDIDO ESTÁ SENDO PREPARADO! Nossa equipe já começou a preparar tudo com muito carinho.',
      pronto: '✅ Seu pedido está pronto! Você já pode retirar no balcão.',
      saiu_entrega: '🛵 Seu pedido saiu para entrega! Em breve ele chegará até você.',
      entregue: 'Pedido entregue! Agradecemos pela preferência. Esperamos ver você novamente!',
      cancelado: 'Informamos que seu pedido foi cancelado. Consulte os detalhes e as informações sobre o reembolso, quando aplicável.'
    },
    soundAlertsEnabled: true,
    soundVolume: 0.8,
    printerWidth: '80mm',
    autoAcceptOrders: false,
    kitchenStations: ['Geral', 'Chapa', 'Fritadeira', 'Montagem', 'Bebidas']
  };

  const notifications: SystemNotification[] = [
    {
      id: 'notif-1',
      type: 'novo_pedido',
      title: '🔔 Novo Pedido Recebido!',
      message: 'Pedido #1004 — 1 Smash Burger Clássico Duplo. Total: R$ 43,90.',
      orderId: 'ord-1004',
      timestamp: formatTime(2),
      read: false
    },
    {
      id: 'notif-2',
      type: 'estoque_baixo',
      title: '⚠️ Alerta de Estoque Crítico',
      message: 'Coca-Cola Lata 350ml atingiu estoque baixo (8 un). Mínimo configurado: 24 un.',
      timestamp: formatTime(40),
      read: false
    },
    {
      id: 'notif-3',
      type: 'novo_pedido',
      title: 'Pedido Pronto na Cozinha',
      message: 'Pedido #1003 está pronto para retirada no balcão.',
      orderId: 'ord-1003',
      timestamp: formatTime(3),
      read: true
    }
  ];

  const auditLogs: SystemAuditLog[] = [
    {
      id: 'aud-1',
      timestamp: formatTime(360),
      userId: 'usr-3',
      userName: 'Gabriel Caixa',
      action: 'Abertura de Caixa',
      details: 'Caixa aberto com fundo inicial de R$ 150,00',
      category: 'caixa'
    },
    {
      id: 'aud-2',
      timestamp: formatTime(300),
      userId: 'usr-3',
      userName: 'Gabriel Caixa',
      action: 'Suprimento de Caixa',
      details: 'Suprimento de R$ 100,00 registrado (reforço de troco)',
      category: 'caixa'
    },
    {
      id: 'aud-3',
      timestamp: formatTime(35),
      userId: 'usr-1',
      userName: 'Sistema Web',
      action: 'Pedido Criado',
      details: 'Pedido #1001 registrado pelo cliente Lucas Ferreira',
      category: 'pedido'
    }
  ];

  return {
    categories,
    products,
    inventory,
    inventoryMovements: [],
    orders,
    cashRegisters,
    cashMovements,
    expenses,
    customers,
    coupons,
    couriers,
    suppliers,
    users,
    settings,
    notifications,
    auditLogs
  };
}

let db: DatabaseSchema;

function loadDatabase(): DatabaseSchema {
  try {
    if (fs.existsSync(DB_FILE)) {
      const content = fs.readFileSync(DB_FILE, 'utf-8');
      const parsed = JSON.parse(content);
      return parsed;
    }
  } catch (err) {
    console.error('Error reading db file, falling back to seed data:', err);
  }
  const initial = getInitialDatabase();
  saveDatabase(initial);
  return initial;
}

function saveDatabase(data: DatabaseSchema): void {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving local db file:', err);
  }
  // Persist to Supabase when server-side credentials are configured.
  void persistDatabaseToSupabase(data);
}

const supabaseUrl = process.env.SUPABASE_URL?.replace(/\/$/, '');
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
let supabaseWriteQueue = Promise.resolve();

async function persistDatabaseToSupabase(data: DatabaseSchema): Promise<void> {
  if (!supabaseUrl || !supabaseServiceKey) return;
  supabaseWriteQueue = supabaseWriteQueue.then(async () => {
    const response = await fetch(`${supabaseUrl}/rest/v1/burgerflow_state?on_conflict=id`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': supabaseServiceKey,
        'Authorization': `Bearer ${supabaseServiceKey}`,
        'Prefer': 'resolution=merge-duplicates,return=minimal'
      },
      body: JSON.stringify({ id: 'main', data, updated_at: new Date().toISOString() })
    });
    if (!response.ok) throw new Error(`Supabase save failed (${response.status}): ${await response.text()}`);
  }).catch(err => console.error('Could not persist BurgerFlow data to Supabase:', err));
  await supabaseWriteQueue;
}

async function restoreDatabaseFromSupabase(): Promise<void> {
  if (!supabaseUrl || !supabaseServiceKey) {
    console.warn('Supabase is not configured. Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY on the server.');
    return;
  }
  const response = await fetch(`${supabaseUrl}/rest/v1/burgerflow_state?select=data&id=eq.main`, {
    headers: { 'apikey': supabaseServiceKey, 'Authorization': `Bearer ${supabaseServiceKey}` }
  });
  if (!response.ok) throw new Error(`Supabase load failed (${response.status}): ${await response.text()}`);
  const rows = await response.json() as Array<{data: DatabaseSchema}>;
  if (rows.length && rows[0].data) {
    db = rows[0].data;
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
    console.log('BurgerFlow data loaded from Supabase.');
  } else {
    await persistDatabaseToSupabase(db);
    console.log('Initial BurgerFlow data saved to Supabase.');
  }
}

db = loadDatabase();

// SSE Connected clients pool
const sseClients = new Set<express.Response>();

function broadcastSSE(type: string, payload: any) {
  const data = JSON.stringify({ type, payload, timestamp: new Date().toISOString() });
  for (const res of sseClients) {
    try {
      res.write(`data: ${data}\n\n`);
    } catch {
      sseClients.delete(res);
    }
  }
}

async function startServer() {
  const app = express();
  app.use(express.json());

  // SSE Endpoint
  app.get('/api/events', (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders?.();

    sseClients.add(res);

    // Initial ping
    res.write(`data: ${JSON.stringify({ type: 'connected', message: 'SSE BurgerFlow connected' })}\n\n`);

    req.on('close', () => {
      sseClients.delete(res);
    });
  });

  // Bootstrap full app state in single call
  app.get('/api/bootstrap', (req, res) => {
    res.json(db);
  });

  // Reset / seed demo
  app.post('/api/system/reset-demo', (req, res) => {
    db = getInitialDatabase();
    saveDatabase(db);
    broadcastSSE('db_reset', db);
    res.json({ success: true, message: 'Dados restaurados com sucesso para demonstração inicial.' });
  });

  // Settings
  app.get('/api/settings', (req, res) => {
    res.json(db.settings);
  });

  app.put('/api/settings', (req, res) => {
    db.settings = { ...db.settings, ...req.body };
    saveDatabase(db);
    broadcastSSE('settings_updated', db.settings);
    res.json(db.settings);
  });

  // Notifications
  app.get('/api/notifications', (req, res) => {
    res.json(db.notifications);
  });

  app.post('/api/notifications/:id/read', (req, res) => {
    const item = db.notifications.find(n => n.id === req.params.id);
    if (item) {
      item.read = true;
      saveDatabase(db);
      broadcastSSE('notifications_updated', db.notifications);
    }
    res.json({ success: true });
  });

  app.post('/api/notifications/read-all', (req, res) => {
    db.notifications.forEach(n => { n.read = true; });
    saveDatabase(db);
    broadcastSSE('notifications_updated', db.notifications);
    res.json({ success: true });
  });

  // Products
  app.get('/api/products', (req, res) => {
    res.json(db.products);
  });

  app.post('/api/products', (req, res) => {
    const newProduct: Product = {
      ...req.body,
      id: 'prod-' + Date.now()
    };
    db.products.push(newProduct);
    saveDatabase(db);
    broadcastSSE('product_created', newProduct);
    res.status(201).json(newProduct);
  });

  app.put('/api/products/:id', (req, res) => {
    const index = db.products.findIndex(p => p.id === req.params.id);
    if (index === -1) return res.status(404).json({ error: 'Produto não encontrado' });
    db.products[index] = { ...db.products[index], ...req.body };
    saveDatabase(db);
    broadcastSSE('product_updated', db.products[index]);
    res.json(db.products[index]);
  });

  app.delete('/api/products/:id', (req, res) => {
    db.products = db.products.filter(p => p.id !== req.params.id);
    saveDatabase(db);
    broadcastSSE('product_deleted', { id: req.params.id });
    res.json({ success: true });
  });

  // Categories
  app.get('/api/categories', (req, res) => {
    res.json(db.categories);
  });

  app.post('/api/categories', (req, res) => {
    const newCategory: Category = {
      ...req.body,
      id: 'cat-' + Date.now()
    };
    db.categories.push(newCategory);
    saveDatabase(db);
    broadcastSSE('category_created', newCategory);
    res.status(201).json(newCategory);
  });

  app.put('/api/categories/:id', (req, res) => {
    const index = db.categories.findIndex(c => c.id === req.params.id);
    if (index === -1) return res.status(404).json({ error: 'Categoria não encontrada' });
    db.categories[index] = { ...db.categories[index], ...req.body };
    saveDatabase(db);
    broadcastSSE('category_updated', db.categories[index]);
    res.json(db.categories[index]);
  });

  app.delete('/api/categories/:id', (req, res) => {
    db.categories = db.categories.filter(c => c.id !== req.params.id);
    saveDatabase(db);
    broadcastSSE('category_deleted', { id: req.params.id });
    res.json({ success: true });
  });

  // Inventory
  app.get('/api/inventory', (req, res) => {
    res.json(db.inventory);
  });

  app.post('/api/inventory', (req, res) => {
    const newItem: InventoryItem = {
      ...req.body,
      id: 'inv-' + Date.now(),
      reservedQuantity: 0
    };
    db.inventory.push(newItem);
    saveDatabase(db);
    broadcastSSE('inventory_updated', db.inventory);
    res.status(201).json(newItem);
  });

  app.put('/api/inventory/:id', (req, res) => {
    const index = db.inventory.findIndex(i => i.id === req.params.id);
    if (index === -1) return res.status(404).json({ error: 'Item de estoque não encontrado' });
    db.inventory[index] = { ...db.inventory[index], ...req.body };
    saveDatabase(db);
    broadcastSSE('inventory_updated', db.inventory);
    res.json(db.inventory[index]);
  });

  app.post('/api/inventory/movement', (req, res) => {
    const { itemId, type, quantity, reason, userId, unitCost } = req.body;
    const item = db.inventory.find(i => i.id === itemId);
    if (!item) return res.status(404).json({ error: 'Item não encontrado' });

    const qty = Number(quantity);
    if (isNaN(qty) || qty <= 0) return res.status(400).json({ error: 'Quantidade inválida' });

    if (type === 'entrada' || type === 'compra' || type === 'devolucao_cancelamento') {
      item.currentQuantity += qty;
    } else if (type === 'saida_manual' || type === 'perda_desperdicio' || type === 'vencido' || type === 'consumo_producao') {
      item.currentQuantity = Math.max(0, item.currentQuantity - qty);
    } else if (type === 'ajuste_inventario') {
      item.currentQuantity = qty;
    }

    const movement: InventoryMovement = {
      id: 'mov-' + Date.now(),
      itemId: item.id,
      itemName: item.name,
      type,
      quantity: qty,
      unitCost: unitCost || item.unitCost,
      date: new Date().toISOString(),
      reason: reason || 'Movimentação manual',
      userId: userId || 'usr-1'
    };

    db.inventoryMovements.push(movement);

    // Audit log
    db.auditLogs.unshift({
      id: 'aud-' + Date.now(),
      timestamp: new Date().toISOString(),
      userId: userId || 'usr-1',
      userName: 'Operador de Estoque',
      action: 'Movimentação de Estoque: ' + type,
      details: `${item.name}: ${qty} ${item.unit} (${reason})`,
      category: 'estoque'
    });

    // Check low stock
    if (item.currentQuantity <= item.minQuantity) {
      const notif: SystemNotification = {
        id: 'notif-' + Date.now(),
        type: 'estoque_baixo',
        title: '⚠️ Estoque Baixo / Crítico',
        message: `${item.name} atingiu ${item.currentQuantity} ${item.unit} (mínimo: ${item.minQuantity} ${item.unit}).`,
        timestamp: new Date().toISOString(),
        read: false
      };
      db.notifications.unshift(notif);
      broadcastSSE('notification', notif);
    }

    saveDatabase(db);
    broadcastSSE('inventory_updated', db.inventory);
    res.json({ success: true, item, movement });
  });

  // Orders
  app.get('/api/orders', (req, res) => {
    res.json(db.orders);
  });

  app.post('/api/orders', (req, res) => {
    const rawOrder = req.body;
    const nextNumber = db.orders.length > 0 ? Math.max(...db.orders.map(o => o.orderNumber)) + 1 : 1001;
    const nowIso = new Date().toISOString();

    const initialStatus: OrderStatus = rawOrder.status || (db.settings.autoAcceptOrders ? 'confirmado' : 'recebido');

    const newOrder: Order = {
      ...rawOrder,
      id: 'ord-' + Date.now(),
      orderNumber: nextNumber,
      status: initialStatus,
      createdAt: nowIso,
      updatedAt: nowIso,
      statusHistory: [
        {
          status: initialStatus,
          timestamp: nowIso,
          updatedBy: rawOrder.createdByName || 'Cliente via Web',
          note: 'Pedido aberto no sistema'
        }
      ],
      communicationLog: [
        {
          id: 'com-' + Date.now(),
          channel: 'app',
          message: db.settings.automatedMessages[initialStatus] || db.settings.automatedMessages.recebido,
          status: 'sent',
          timestamp: nowIso
        }
      ],
      stockStatus: 'none'
    };

    // Customer association/loyalty
    if (newOrder.customerPhone) {
      let customer = db.customers.find(c => c.phone.replace(/\D/g, '') === newOrder.customerPhone.replace(/\D/g, ''));
      if (customer) {
        customer.ordersCount += 1;
        customer.totalSpent += newOrder.total;
        customer.points += Math.floor(newOrder.total);
        customer.lastOrderDate = nowIso;
        if (newOrder.customerAddress && !customer.addresses.some(a => a.street === newOrder.customerAddress?.street && a.number === newOrder.customerAddress?.number)) {
          customer.addresses.push(newOrder.customerAddress);
        }
      } else {
        customer = {
          id: 'cust-' + Date.now(),
          name: newOrder.customerName,
          phone: newOrder.customerPhone,
          addresses: newOrder.customerAddress ? [newOrder.customerAddress] : [],
          ordersCount: 1,
          totalSpent: newOrder.total,
          points: Math.floor(newOrder.total),
          createdAt: nowIso,
          lastOrderDate: nowIso
        };
        db.customers.push(customer);
      }
    }

    // Deduct/reserve stock if confirmed right away
    if (initialStatus === 'confirmado' || initialStatus === 'em_preparacao') {
      reserveOrDeductStock(newOrder, 'deduct');
    }

    db.orders.unshift(newOrder);

    // Notification
    const itemsSummary = newOrder.items.map(i => `${i.quantity}x ${i.productName}`).join(', ');
    const notif: SystemNotification = {
      id: 'notif-' + Date.now(),
      type: 'novo_pedido',
      title: '🔔 NOVO PEDIDO RECEBIDO!',
      message: `Pedido #${newOrder.orderNumber} — ${itemsSummary}. Total: R$ ${newOrder.total.toFixed(2)}.`,
      orderId: newOrder.id,
      timestamp: nowIso,
      read: false
    };
    db.notifications.unshift(notif);

    // Audit Log
    db.auditLogs.unshift({
      id: 'aud-' + Date.now(),
      timestamp: nowIso,
      userId: rawOrder.userId || 'cliente-web',
      userName: rawOrder.createdByName || newOrder.customerName,
      action: 'Novo Pedido #' + newOrder.orderNumber,
      details: `${newOrder.orderType.toUpperCase()} - R$ ${newOrder.total.toFixed(2)} (${newOrder.paymentMethod})`,
      category: 'pedido'
    });

    saveDatabase(db);
    broadcastSSE('order_created', newOrder);
    broadcastSSE('notification', notif);

    res.status(201).json(newOrder);
  });

  // Helper for recipe stock deductions
  function reserveOrDeductStock(order: Order, action: 'reserve' | 'deduct' | 'return') {
    for (const item of order.items) {
      const product = db.products.find(p => p.id === item.productId);
      if (!product || !product.ingredients) continue;

      for (const ing of product.ingredients) {
        const invItem = db.inventory.find(i => i.id === ing.inventoryItemId);
        if (!invItem) continue;

        const totalQty = ing.quantity * item.quantity;

        if (action === 'reserve') {
          invItem.reservedQuantity += totalQty;
        } else if (action === 'deduct') {
          invItem.currentQuantity = Math.max(0, invItem.currentQuantity - totalQty);
          // Register production consumption
          db.inventoryMovements.push({
            id: 'mov-' + Date.now() + '-' + Math.random().toString(36).substring(2, 5),
            itemId: invItem.id,
            itemName: invItem.name,
            type: 'consumo_producao',
            quantity: totalQty,
            unitCost: invItem.unitCost,
            date: new Date().toISOString(),
            reason: `Produção Pedido #${order.orderNumber} (${product.name})`,
            userId: 'sistema',
            orderId: order.id
          });
        } else if (action === 'return') {
          invItem.currentQuantity += totalQty;
          db.inventoryMovements.push({
            id: 'mov-' + Date.now() + '-' + Math.random().toString(36).substring(2, 5),
            itemId: invItem.id,
            itemName: invItem.name,
            type: 'devolucao_cancelamento',
            quantity: totalQty,
            unitCost: invItem.unitCost,
            date: new Date().toISOString(),
            reason: `Estorno Pedido Cancelado #${order.orderNumber}`,
            userId: 'sistema',
            orderId: order.id
          });
        }
      }
    }
  }

  // Update order status
  app.patch('/api/orders/:id/status', (req, res) => {
    const { status, updatedBy, reason, courierId, courierName } = req.body;
    const order = db.orders.find(o => o.id === req.params.id);
    if (!order) return res.status(404).json({ error: 'Pedido não encontrado' });

    const prevStatus = order.status;
    const nowIso = new Date().toISOString();

    order.status = status;
    order.updatedAt = nowIso;

    if (reason) order.cancellationReason = reason;
    if (courierId) order.courierId = courierId;
    if (courierName) order.courierName = courierName;

    // Stock management rules based on status transition
    if (status === 'confirmado' || status === 'em_preparacao') {
      if (order.stockStatus === 'none') {
        reserveOrDeductStock(order, 'deduct');
        order.stockStatus = 'deducted';
      }
    } else if (status === 'cancelado') {
      if (order.stockStatus === 'deducted' || order.stockStatus === 'reserved') {
        reserveOrDeductStock(order, 'return');
        order.stockStatus = 'returned';
      }
    }

    // Cash register updates on delivery/conclusion
    if (status === 'entregue' && order.paymentStatus !== 'pago') {
      order.paymentStatus = 'pago';
    }

    // If order was delivered/finished and payment is recorded, update active open cash register
    if (status === 'entregue' && prevStatus !== 'entregue') {
      const activeCash = db.cashRegisters.find(c => c.status === 'open');
      if (activeCash) {
        if (order.paymentMethod === 'dinheiro') {
          activeCash.salesCash += order.total;
          activeCash.currentCash += order.total;
        } else if (order.paymentMethod === 'pix') {
          activeCash.salesPix += order.total;
        } else {
          activeCash.salesCard += order.total;
        }
        activeCash.totalSales += order.total;
      }
    }

    // Add status history
    order.statusHistory.push({
      status,
      timestamp: nowIso,
      updatedBy: updatedBy || 'Equipe Lanchonete',
      note: reason || undefined
    });

    // Communication log message from template
    const msgTemplate = db.settings.automatedMessages[status as OrderStatus];
    if (msgTemplate) {
      order.communicationLog.push({
        id: 'com-' + Date.now(),
        channel: order.orderType === 'delivery' ? 'whatsapp' : 'app',
        message: msgTemplate,
        status: 'sent',
        timestamp: nowIso
      });
    }

    // Audit log
    db.auditLogs.unshift({
      id: 'aud-' + Date.now(),
      timestamp: nowIso,
      userId: updatedBy || 'operador',
      userName: updatedBy || 'Operador',
      action: `Status Pedido #${order.orderNumber}: ${status}`,
      details: reason ? `Justificativa: ${reason}` : `Alterado de ${prevStatus} para ${status}`,
      category: 'pedido'
    });

    // Notification if canceled
    if (status === 'cancelado') {
      const notif: SystemNotification = {
        id: 'notif-' + Date.now(),
        type: 'pedido_cancelado',
        title: `Pedido #${order.orderNumber} Cancelado`,
        message: `Motivo: ${reason || 'Não informado'}. Total: R$ ${order.total.toFixed(2)}.`,
        orderId: order.id,
        timestamp: nowIso,
        read: false
      };
      db.notifications.unshift(notif);
      broadcastSSE('notification', notif);
    }

    saveDatabase(db);
    broadcastSSE('order_updated', order);
    broadcastSSE('inventory_updated', db.inventory);

    res.json(order);
  });

  // Cash Register operations
  app.get('/api/cash-register', (req, res) => {
    const active = db.cashRegisters.find(c => c.status === 'open');
    res.json({
      active: active || null,
      history: db.cashRegisters,
      movements: db.cashMovements
    });
  });

  app.post('/api/cash-register/open', (req, res) => {
    const { initialCash, openedBy, notes } = req.body;
    const existing = db.cashRegisters.find(c => c.status === 'open');
    if (existing) return res.status(400).json({ error: 'Já existe um caixa aberto no momento.' });

    const initial = Number(initialCash) || 0;
    const newRegister: CashRegister = {
      id: 'cx-' + Date.now(),
      openedAt: new Date().toISOString(),
      openedBy: openedBy || 'Operador de Caixa',
      initialCash: initial,
      currentCash: initial,
      salesCash: 0,
      salesCard: 0,
      salesPix: 0,
      totalSales: 0,
      sangrias: 0,
      suprimentos: 0,
      status: 'open',
      notes
    };

    db.cashRegisters.unshift(newRegister);

    db.auditLogs.unshift({
      id: 'aud-' + Date.now(),
      timestamp: new Date().toISOString(),
      userId: openedBy || 'caixa',
      userName: openedBy || 'Operador',
      action: 'Abertura de Caixa',
      details: `Fundo inicial: R$ ${initial.toFixed(2)}`,
      category: 'caixa'
    });

    saveDatabase(db);
    broadcastSSE('cash_register_updated', newRegister);
    res.status(201).json(newRegister);
  });

  app.post('/api/cash-register/close', (req, res) => {
    const { finalCashCounted, closedBy, notes } = req.body;
    const active = db.cashRegisters.find(c => c.status === 'open');
    if (!active) return res.status(400).json({ error: 'Nenhum caixa está aberto para fechamento.' });

    const counted = Number(finalCashCounted) || 0;
    const expected = active.initialCash + active.salesCash + active.suprimentos - active.sangrias;
    const diff = counted - expected;

    active.status = 'closed';
    active.closedAt = new Date().toISOString();
    active.closedBy = closedBy || 'Operador de Caixa';
    active.finalCashCounted = counted;
    active.difference = diff;
    if (notes) active.notes = (active.notes ? active.notes + ' | ' : '') + notes;

    db.auditLogs.unshift({
      id: 'aud-' + Date.now(),
      timestamp: new Date().toISOString(),
      userId: closedBy || 'caixa',
      userName: closedBy || 'Operador',
      action: 'Fechamento de Caixa',
      details: `Contado: R$ ${counted.toFixed(2)} | Esperado: R$ ${expected.toFixed(2)} | Diferença: R$ ${diff.toFixed(2)}`,
      category: 'caixa'
    });

    saveDatabase(db);
    broadcastSSE('cash_register_closed', active);
    res.json(active);
  });

  app.post('/api/cash-register/movement', (req, res) => {
    const { type, amount, reason, operator } = req.body;
    const active = db.cashRegisters.find(c => c.status === 'open');
    if (!active) return res.status(400).json({ error: 'Nenhum caixa aberto para lançar movimentação.' });

    const val = Number(amount);
    if (isNaN(val) || val <= 0) return res.status(400).json({ error: 'Valor inválido.' });

    if (type === 'sangria') {
      active.sangrias += val;
      active.currentCash = Math.max(0, active.currentCash - val);
    } else {
      active.suprimentos += val;
      active.currentCash += val;
    }

    const mov: CashMovement = {
      id: 'mov-' + Date.now(),
      cashRegisterId: active.id,
      type,
      amount: val,
      reason: reason || (type === 'sangria' ? 'Retirada para cofre' : 'Reforço de troco'),
      timestamp: new Date().toISOString(),
      operator: operator || 'Operador'
    };

    db.cashMovements.unshift(mov);

    db.auditLogs.unshift({
      id: 'aud-' + Date.now(),
      timestamp: new Date().toISOString(),
      userId: operator || 'caixa',
      userName: operator || 'Operador',
      action: type === 'sangria' ? 'Sangria de Caixa' : 'Suprimento de Caixa',
      details: `R$ ${val.toFixed(2)} (${reason})`,
      category: 'caixa'
    });

    saveDatabase(db);
    broadcastSSE('cash_register_updated', active);
    res.json({ success: true, movement: mov, cashRegister: active });
  });

  // Financial Expenses
  app.get('/api/expenses', (req, res) => {
    res.json(db.expenses);
  });

  app.post('/api/expenses', (req, res) => {
    const newExp: Expense = {
      ...req.body,
      id: 'exp-' + Date.now()
    };
    db.expenses.unshift(newExp);
    saveDatabase(db);
    broadcastSSE('expense_updated', newExp);
    res.status(201).json(newExp);
  });

  app.put('/api/expenses/:id', (req, res) => {
    const index = db.expenses.findIndex(e => e.id === req.params.id);
    if (index === -1) return res.status(404).json({ error: 'Despesa não encontrada' });
    db.expenses[index] = { ...db.expenses[index], ...req.body };
    saveDatabase(db);
    broadcastSSE('expense_updated', db.expenses[index]);
    res.json(db.expenses[index]);
  });

  app.delete('/api/expenses/:id', (req, res) => {
    db.expenses = db.expenses.filter(e => e.id !== req.params.id);
    saveDatabase(db);
    res.json({ success: true });
  });

  // Couriers
  app.get('/api/couriers', (req, res) => {
    res.json(db.couriers);
  });

  app.post('/api/couriers', (req, res) => {
    const newCourier: Courier = {
      ...req.body,
      id: 'cour-' + Date.now(),
      currentDeliveriesCount: 0
    };
    db.couriers.push(newCourier);
    saveDatabase(db);
    res.status(201).json(newCourier);
  });

  app.put('/api/couriers/:id', (req, res) => {
    const index = db.couriers.findIndex(c => c.id === req.params.id);
    if (index === -1) return res.status(404).json({ error: 'Entregador não encontrado' });
    db.couriers[index] = { ...db.couriers[index], ...req.body };
    saveDatabase(db);
    res.json(db.couriers[index]);
  });

  // Suppliers
  app.get('/api/suppliers', (req, res) => {
    res.json(db.suppliers);
  });

  app.post('/api/suppliers', (req, res) => {
    const newSup: Supplier = {
      ...req.body,
      id: 'sup-' + Date.now()
    };
    db.suppliers.push(newSup);
    saveDatabase(db);
    res.status(201).json(newSup);
  });

  app.put('/api/suppliers/:id', (req, res) => {
    const index = db.suppliers.findIndex(s => s.id === req.params.id);
    if (index === -1) return res.status(404).json({ error: 'Fornecedor não encontrado' });
    db.suppliers[index] = { ...db.suppliers[index], ...req.body };
    saveDatabase(db);
    res.json(db.suppliers[index]);
  });

  // Coupons
  app.get('/api/coupons', (req, res) => {
    res.json(db.coupons);
  });

  app.post('/api/coupons', (req, res) => {
    const newCoupon: Coupon = {
      ...req.body,
      id: 'coup-' + Date.now(),
      usageCount: 0
    };
    db.coupons.push(newCoupon);
    saveDatabase(db);
    res.status(201).json(newCoupon);
  });

  // Customers
  app.get('/api/customers', (req, res) => {
    res.json(db.customers);
  });

  app.post('/api/customers', (req, res) => {
    const newCust: Customer = {
      ...req.body,
      id: 'cust-' + Date.now(),
      ordersCount: 0,
      totalSpent: 0,
      points: 0,
      createdAt: new Date().toISOString()
    };
    db.customers.push(newCust);
    saveDatabase(db);
    res.status(201).json(newCust);
  });

  // Audit
  app.get('/api/audit', (req, res) => {
    res.json(db.auditLogs);
  });

  // Mount Vite middleware in development
  const isProduction = process.env.NODE_ENV === 'production';
  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files from dist
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  const PORT = 3000;
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`BurgerFlow server running at http://0.0.0.0:${PORT}`);
  });
}

restoreDatabaseFromSupabase()
  .then(() => startServer())
  .catch(err => {
    console.error('Failed to initialize BurgerFlow:', err);
    process.exit(1);
  });
