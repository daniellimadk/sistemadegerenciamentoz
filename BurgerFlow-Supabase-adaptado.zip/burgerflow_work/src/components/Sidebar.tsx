import React from 'react';
import { useApp, type AppView } from '../context/AppContext.tsx';
import {
  LayoutDashboard,
  ClipboardList,
  ChefHat,
  MonitorCheck,
  CreditCard,
  Package,
  UtensilsCrossed,
  DollarSign,
  Truck,
  Users,
  Building2,
  Settings,
  Smartphone,
  Flame,
  X
} from 'lucide-react';

interface SidebarProps {
  isMobileOpen?: boolean;
  onCloseMobile?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isMobileOpen, onCloseMobile }) => {
  const { currentView, setCurrentView, orders, inventory } = useApp();

  const activeOrdersCount = orders.filter(
    o => o.status === 'recebido' || o.status === 'aguardando_confirmacao' || o.status === 'confirmado'
  ).length;

  const kitchenOrdersCount = orders.filter(
    o => o.status === 'confirmado' || o.status === 'em_preparacao'
  ).length;

  const lowStockCount = inventory.filter(
    i => i.currentQuantity <= i.minQuantity
  ).length;

  const navItems: Array<{
    id: AppView;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: number;
    badgeColor?: string;
  }> = [
    { id: 'dashboard', label: 'Painel Geral', icon: LayoutDashboard },
    {
      id: 'orders',
      label: 'Gerenciador de Pedidos',
      icon: ClipboardList,
      badge: activeOrdersCount > 0 ? activeOrdersCount : undefined,
      badgeColor: 'bg-amber-500 text-white'
    },
    {
      id: 'kitchen',
      label: 'Cozinha (KDS)',
      icon: ChefHat,
      badge: kitchenOrdersCount > 0 ? kitchenOrdersCount : undefined,
      badgeColor: 'bg-orange-600 text-white'
    },
    { id: 'pos', label: 'PDV Balcão Rápido', icon: MonitorCheck },
    { id: 'cash-register', label: 'Controle de Caixa', icon: CreditCard },
    {
      id: 'inventory',
      label: 'Estoque Inteligente',
      icon: Package,
      badge: lowStockCount > 0 ? lowStockCount : undefined,
      badgeColor: 'bg-rose-500 text-white'
    },
    { id: 'products', label: 'Cardápio & Fichas', icon: UtensilsCrossed },
    { id: 'financial', label: 'Financeiro & DRE', icon: DollarSign },
    { id: 'delivery', label: 'Entregas & Motoboys', icon: Truck },
    { id: 'customers', label: 'Clientes & Fidelidade', icon: Users },
    { id: 'suppliers', label: 'Fornecedores & Compras', icon: Building2 },
    { id: 'settings', label: 'Configurações', icon: Settings },
  ];

  const handleSelect = (view: AppView) => {
    setCurrentView(view);
    if (onCloseMobile) onCloseMobile();
  };

  const content = (
    <div className="flex flex-col h-full bg-stone-900 text-stone-300 w-64 select-none">
      {/* Brand logo banner */}
      <div className="p-5 flex items-center justify-between border-b border-stone-800">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-600 to-amber-500 flex items-center justify-center text-white shadow-sm font-bold text-lg">
            🍔
          </div>
          <div>
            <div className="font-bold text-stone-100 text-sm tracking-tight flex items-center gap-1.5">
              BurgerFlow
              <span className="text-[10px] bg-amber-500/20 text-amber-400 font-semibold px-1.5 py-0.2 rounded-xs border border-amber-500/30">
                PRO
              </span>
            </div>
            <div className="text-[11px] text-stone-400">Gestão de Lanchonete</div>
          </div>
        </div>
        {onCloseMobile && (
          <button
            type="button"
            onClick={onCloseMobile}
            className="lg:hidden text-stone-400 hover:text-stone-100 p-1 rounded-md"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Navigation list */}
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        <div className="px-3 pb-2 text-[10px] font-semibold text-stone-500 uppercase tracking-wider">
          Módulos Operacionais
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => handleSelect(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium transition-all ${
                isActive
                  ? 'bg-amber-600 text-white font-semibold shadow-xs'
                  : 'text-stone-300 hover:bg-stone-800/80 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-stone-400'}`} />
                <span>{item.label}</span>
              </div>
              {item.badge !== undefined && (
                <span
                  className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${
                    isActive ? 'bg-stone-900 text-white' : item.badgeColor
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}

        {/* Client Menu Shortcut */}
        <div className="pt-4 mt-4 border-t border-stone-800 px-3">
          <div className="text-[10px] font-semibold text-stone-500 uppercase tracking-wider mb-2">
            Visão do Consumidor
          </div>
          <button
            type="button"
            onClick={() => handleSelect('customer-menu')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold transition-all ${
              currentView === 'customer-menu'
                ? 'bg-amber-500 text-stone-950 font-bold'
                : 'bg-stone-800/60 hover:bg-stone-800 text-amber-400 border border-stone-700/60'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>Cardápio Online Cliente</span>
          </button>
        </div>
      </nav>

      {/* Bottom Profile / Quick Info */}
      <div className="p-4 border-t border-stone-800 text-[11px] text-stone-500 flex items-center justify-between">
        <span>BurgerFlow v2.4</span>
        <span className="text-emerald-500 font-mono flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />
          Online
        </span>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop fixed sidebar */}
      <aside className="hidden lg:block shrink-0 sticky top-0 h-screen z-40 border-r border-stone-800">
        {content}
      </aside>

      {/* Mobile Drawer */}
      {isMobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-xs"
            onClick={onCloseMobile}
          />
          <div className="relative z-50 shadow-2xl">
            {content}
          </div>
        </div>
      )}
    </>
  );
};
