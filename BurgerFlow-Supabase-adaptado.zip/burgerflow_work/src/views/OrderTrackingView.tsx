import React from 'react';
import { useApp } from '../context/AppContext.tsx';
import {
  formatCurrency,
  formatDateTime,
  formatTimeOnly,
  ORDER_STATUS_CONFIG,
  ORDER_TYPE_LABELS
} from '../utils/formatters.ts';
import {
  CheckCircle2,
  Clock,
  MapPin,
  Phone,
  MessageCircle,
  Truck,
  ChefHat,
  ShoppingBag,
  ArrowLeft,
  ChevronRight,
  RotateCcw
} from 'lucide-react';

export const OrderTrackingView: React.FC = () => {
  const {
    orders,
    trackingOrderId,
    setTrackingOrderId,
    settings,
    setCurrentView
  } = useApp();

  const currentOrder = orders.find(o => o.id === trackingOrderId) || orders[0];

  if (!currentOrder) {
    return (
      <div className="p-12 text-center max-w-md mx-auto space-y-4">
        <h2 className="font-bold text-base text-stone-900">Nenhum Pedido Selecionado</h2>
        <button
          type="button"
          onClick={() => setCurrentView('customer-menu')}
          className="px-4 py-2 bg-amber-600 text-white rounded-xl text-xs font-bold"
        >
          Ir para o Cardápio
        </button>
      </div>
    );
  }

  // Steps for timeline:
  // 1: Recebido / Aguardando
  // 2: Confirmado
  // 3: Em Preparo
  // 4: Pronto ou Em Rota
  // 5: Entregue
  const steps = [
    { key: 'recebido', label: 'Pedido Recebido', desc: 'Registrado em nosso sistema' },
    { key: 'confirmado', label: 'Confirmado', desc: 'Conferido pela equipe' },
    { key: 'em_preparacao', label: 'Em Preparo', desc: 'Na chapa e cozinha' },
    {
      key: currentOrder.orderType === 'delivery' ? 'saiu_entrega' : 'pronto',
      label: currentOrder.orderType === 'delivery' ? 'Saiu para Entrega' : 'Pronto p/ Retirada',
      desc: currentOrder.orderType === 'delivery' ? 'A caminho com o entregador' : 'Disponível no balcão'
    },
    { key: 'entregue', label: 'Entregue / Concluído', desc: 'Aproveite sua refeição!' }
  ];

  const getStepIndex = (status: string) => {
    switch (status) {
      case 'recebido':
      case 'aguardando_confirmacao':
        return 0;
      case 'confirmado':
        return 1;
      case 'em_preparacao':
        return 2;
      case 'pronto':
        return currentOrder.orderType === 'delivery' ? 2 : 3;
      case 'saiu_entrega':
        return 3;
      case 'entregue':
        return 4;
      default:
        return 0;
    }
  };

  const currentStepIdx = getStepIndex(currentOrder.status);
  const isCanceled = currentOrder.status === 'cancelado';

  // WhatsApp text link
  const whatsappUrl = `https://wa.me/${settings.whatsapp}?text=${encodeURIComponent(
    `Olá! Gostaria de informações sobre o meu Pedido #${currentOrder.orderNumber} em nome de ${currentOrder.customerName}.`
  )}`;

  return (
    <div className="min-h-screen bg-stone-50 py-8 px-4">
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Navigation & Header */}
        <div className="flex items-center justify-between">
          <button
            type="button"
            onClick={() => setCurrentView('customer-menu')}
            className="flex items-center gap-1.5 text-xs font-semibold text-stone-600 hover:text-stone-900 bg-white px-3 py-2 rounded-xl border border-stone-200 shadow-2xs"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Fazer Novo Pedido</span>
          </button>

          <button
            type="button"
            onClick={() => setCurrentView('dashboard')}
            className="text-xs font-semibold text-stone-500 hover:text-stone-800"
          >
            Painel da Lanchonete &rarr;
          </button>
        </div>

        {/* Main Status Hero Card */}
        <div className="bg-white rounded-2xl border border-stone-200 shadow-sm p-6 space-y-5">
          <div className="flex items-center justify-between border-b border-stone-100 pb-4">
            <div>
              <span className="text-xs text-stone-400 font-mono">ACOMPANHAMENTO EM TEMPO REAL</span>
              <h1 className="text-xl sm:text-2xl font-black text-stone-900 mt-0.5">
                Pedido #{currentOrder.orderNumber}
              </h1>
            </div>

            <span className={`px-3 py-1 text-xs font-bold rounded-full ${
              isCanceled
                ? 'bg-rose-100 text-rose-800'
                : currentOrder.status === 'entregue'
                ? 'bg-emerald-100 text-emerald-800'
                : 'bg-amber-100 text-amber-800'
            }`}>
              {ORDER_STATUS_CONFIG[currentOrder.status]?.label || currentOrder.status}
            </span>
          </div>

          {/* Canceled Notice */}
          {isCanceled && (
            <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-900 space-y-1">
              <strong className="block font-bold">Informamos que seu pedido foi cancelado.</strong>
              <p>Motivo: {currentOrder.cancellationReason || 'Cancelado pela equipe da lanchonete.'}</p>
            </div>
          )}

          {/* Real-time Message Banner */}
          {!isCanceled && (
            <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-xl text-xs text-amber-950 flex items-start gap-3">
              <div className="p-1 bg-amber-500 text-white rounded-lg shrink-0 mt-0.5">
                <ChefHat className="w-4 h-4" />
              </div>
              <div className="space-y-0.5 flex-1">
                <span className="font-bold text-amber-900">Mensagem da Equipe:</span>
                <p className="leading-relaxed">
                  {settings.automatedMessages[currentOrder.status] || 'Seu pedido está sendo processado com todo o cuidado.'}
                </p>
              </div>
            </div>
          )}

          {/* Stepper Timeline */}
          {!isCanceled && (
            <div className="pt-2">
              <div className="relative flex items-center justify-between">
                {/* Connecting bar */}
                <div className="absolute top-4 inset-x-4 h-1 bg-stone-200 -z-0">
                  <div
                    className="h-full bg-amber-500 transition-all duration-500"
                    style={{ width: `${(currentStepIdx / (steps.length - 1)) * 100}%` }}
                  />
                </div>

                {steps.map((st, idx) => {
                  const isDone = idx <= currentStepIdx;
                  const isCurrent = idx === currentStepIdx;

                  return (
                    <div key={st.key} className="flex flex-col items-center relative z-10">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                          isDone
                            ? 'bg-amber-600 text-white ring-4 ring-amber-100'
                            : 'bg-stone-200 text-stone-500'
                        }`}
                      >
                        {isDone ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                      </div>
                      <span className={`text-[11px] mt-2 font-semibold text-center hidden sm:block ${
                        isCurrent ? 'text-amber-700 font-bold' : isDone ? 'text-stone-800' : 'text-stone-400'
                      }`}>
                        {st.label}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Time & Delivery details strip */}
          <div className="grid grid-cols-2 gap-3 pt-3 border-t border-stone-100 text-xs">
            <div className="p-3 bg-stone-50 rounded-xl space-y-0.5">
              <span className="text-stone-400 text-[11px] block">Horário do Pedido</span>
              <strong className="font-mono text-stone-900">{formatTimeOnly(currentOrder.createdAt)}</strong>
            </div>
            <div className="p-3 bg-stone-50 rounded-xl space-y-0.5">
              <span className="text-stone-400 text-[11px] block">Tempo Estimado Total</span>
              <strong className="font-mono text-stone-900">~{currentOrder.estimatedPrepMinutes} minutos</strong>
            </div>
          </div>
        </div>

        {/* Order Items & Totals Card */}
        <div className="bg-white rounded-2xl border border-stone-200 shadow-sm p-6 space-y-4">
          <h3 className="font-bold text-sm text-stone-900">Resumo da Sua Refeição</h3>

          <div className="divide-y divide-stone-100 text-xs">
            {currentOrder.items.map((item, idx) => (
              <div key={idx} className="py-2.5 flex justify-between items-start">
                <div className="space-y-0.5">
                  <div className="font-bold text-stone-900">
                    {item.quantity}x {item.productName}
                  </div>
                  {item.addOns && item.addOns.length > 0 && (
                    <div className="text-[11px] text-stone-500 pl-2">
                      + {item.addOns.map(a => a.name).join(', ')}
                    </div>
                  )}
                  {item.removedIngredients && item.removedIngredients.length > 0 && (
                    <div className="text-[11px] text-rose-600 pl-2">
                      Sem: {item.removedIngredients.join(', ')}
                    </div>
                  )}
                </div>
                <span className="font-mono font-bold text-stone-900">
                  {formatCurrency(item.totalPrice)}
                </span>
              </div>
            ))}
          </div>

          <div className="pt-3 border-t border-stone-100 space-y-1.5 text-xs font-mono">
            <div className="flex justify-between text-stone-600 font-sans">
              <span>Subtotal:</span>
              <span>{formatCurrency(currentOrder.subtotal)}</span>
            </div>
            {currentOrder.deliveryFee > 0 && (
              <div className="flex justify-between text-stone-600 font-sans">
                <span>Taxa de Entrega:</span>
                <span>{formatCurrency(currentOrder.deliveryFee)}</span>
              </div>
            )}
            {currentOrder.discount > 0 && (
              <div className="flex justify-between text-rose-600 font-sans">
                <span>Desconto ({currentOrder.couponCode || 'Promo'}):</span>
                <span>- {formatCurrency(currentOrder.discount)}</span>
              </div>
            )}
            <div className="flex justify-between font-bold text-sm text-stone-900 pt-2 border-t border-stone-200 font-sans">
              <span>Total Pago / A Pagar:</span>
              <span className="font-mono text-amber-600 text-base">{formatCurrency(currentOrder.total)}</span>
            </div>
          </div>
        </div>

        {/* WhatsApp Help CTA */}
        <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 flex items-center justify-between gap-4">
          <div className="space-y-0.5">
            <div className="font-bold text-xs text-emerald-950 flex items-center gap-1.5">
              <MessageCircle className="w-4 h-4 text-emerald-600" />
              Dúvidas sobre o seu pedido?
            </div>
            <div className="text-[11px] text-emerald-800">
              Fale diretamente com a equipe da {settings.restaurantName} no WhatsApp.
            </div>
          </div>
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shrink-0 transition-colors"
          >
            Abrir WhatsApp
          </a>
        </div>
      </div>
    </div>
  );
};
