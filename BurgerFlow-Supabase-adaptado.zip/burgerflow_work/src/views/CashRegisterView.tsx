import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { formatCurrency, formatDateTime } from '../utils/formatters.ts';
import {
  CreditCard,
  Lock,
  Unlock,
  ArrowUpRight,
  ArrowDownRight,
  DollarSign,
  AlertCircle,
  FileText,
  Clock,
  User,
  PlusCircle,
  MinusCircle
} from 'lucide-react';

export const CashRegisterView: React.FC = () => {
  const {
    cashRegister,
    cashMovements,
    openCashRegister,
    closeCashRegister,
    addCashMovement,
    currentUser
  } = useApp();

  // Modals / forms
  const [showOpenModal, setShowOpenModal] = useState(false);
  const [initialCashInput, setInitialCashInput] = useState('150.00');
  const [openNotes, setOpenNotes] = useState('');

  const [showCloseModal, setShowCloseModal] = useState(false);
  const [countedCashInput, setCountedCashInput] = useState('');
  const [closeNotes, setCloseNotes] = useState('');

  const [showMovementModal, setShowMovementModal] = useState<'sangria' | 'suprimento' | null>(null);
  const [movementAmount, setMovementAmount] = useState('');
  const [movementReason, setMovementReason] = useState('');

  // Calculations for active register
  const expectedPhysicalCash = cashRegister
    ? cashRegister.initialCash + cashRegister.salesCash + cashRegister.suprimentos - cashRegister.sangrias
    : 0;

  const handleOpen = async () => {
    const val = parseFloat(initialCashInput) || 0;
    await openCashRegister(val, openNotes);
    setShowOpenModal(false);
    setOpenNotes('');
  };

  const handleClose = async () => {
    const counted = parseFloat(countedCashInput) || 0;
    await closeCashRegister(counted, closeNotes);
    setShowCloseModal(false);
    setCountedCashInput('');
    setCloseNotes('');
  };

  const handleMovement = async () => {
    if (!showMovementModal) return;
    const amount = parseFloat(movementAmount) || 0;
    if (amount <= 0) return;
    await addCashMovement(showMovementModal, amount, movementReason);
    setShowMovementModal(null);
    setMovementAmount('');
    setMovementReason('');
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Title & Status */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-stone-900">
            Controle de Caixa & Turnos
          </h1>
          <p className="text-xs sm:text-sm text-stone-500 mt-0.5">
            Gestão de fundo de troco, suprimentos, sangrias e conferência de fechamento.
          </p>
        </div>

        {cashRegister ? (
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setShowMovementModal('suprimento')}
              className="flex items-center gap-1.5 px-3 py-2 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 rounded-lg text-xs font-semibold transition-colors"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Suprimento (Entrada)</span>
            </button>
            <button
              type="button"
              onClick={() => setShowMovementModal('sangria')}
              className="flex items-center gap-1.5 px-3 py-2 bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 rounded-lg text-xs font-semibold transition-colors"
            >
              <MinusCircle className="w-4 h-4" />
              <span>Sangria (Retirada)</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setCountedCashInput(expectedPhysicalCash.toString());
                setShowCloseModal(true);
              }}
              className="flex items-center gap-1.5 px-3 py-2 bg-stone-900 text-white hover:bg-stone-800 rounded-lg text-xs font-semibold transition-colors"
            >
              <Lock className="w-4 h-4" />
              <span>Fechar Caixa</span>
            </button>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => setShowOpenModal(true)}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold shadow-xs transition-colors"
          >
            <Unlock className="w-4 h-4" />
            <span>Abrir Novo Turno de Caixa</span>
          </button>
        )}
      </div>

      {/* Current Register Overview Cards */}
      {cashRegister ? (
        <div className="space-y-6">
          <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="font-bold text-emerald-950">Caixa Aberto</span>
              <span className="text-emerald-700">· Operador: {cashRegister.openedBy}</span>
              <span className="text-emerald-700">· Desde: {formatDateTime(cashRegister.openedAt)}</span>
            </div>
            {cashRegister.notes && (
              <span className="text-emerald-800 italic">"{cashRegister.notes}"</span>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-2xs">
              <span className="text-xs text-stone-500 font-medium">Saldo Físico em Gaveta</span>
              <div className="text-2xl font-bold text-stone-900 font-mono mt-2">
                {formatCurrency(expectedPhysicalCash)}
              </div>
              <div className="text-[11px] text-stone-500 mt-2 pt-2 border-t border-stone-100">
                Fundo Inicial: <strong className="font-mono">{formatCurrency(cashRegister.initialCash)}</strong>
              </div>
            </div>

            <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-2xs">
              <span className="text-xs text-stone-500 font-medium">Vendas em Dinheiro</span>
              <div className="text-2xl font-bold text-emerald-700 font-mono mt-2">
                {formatCurrency(cashRegister.salesCash)}
              </div>
              <div className="text-[11px] text-stone-500 mt-2 pt-2 border-t border-stone-100">
                Somado ao dinheiro físico
              </div>
            </div>

            <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-2xs">
              <span className="text-xs text-stone-500 font-medium">Vendas em Cartão / Pix</span>
              <div className="text-2xl font-bold text-blue-900 font-mono mt-2">
                {formatCurrency(cashRegister.salesCard + cashRegister.salesPix)}
              </div>
              <div className="text-[11px] text-stone-500 mt-2 pt-2 border-t border-stone-100 flex justify-between">
                <span>Cartões: <strong className="font-mono">{formatCurrency(cashRegister.salesCard)}</strong></span>
                <span>Pix: <strong className="font-mono">{formatCurrency(cashRegister.salesPix)}</strong></span>
              </div>
            </div>

            <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-2xs">
              <span className="text-xs text-stone-500 font-medium">Faturamento Total do Turno</span>
              <div className="text-2xl font-bold text-amber-700 font-mono mt-2">
                {formatCurrency(cashRegister.totalSales)}
              </div>
              <div className="text-[11px] text-stone-500 mt-2 pt-2 border-t border-stone-100 flex justify-between">
                <span className="text-emerald-700">+ Supr: {formatCurrency(cashRegister.suprimentos)}</span>
                <span className="text-rose-700">- Sangr: {formatCurrency(cashRegister.sangrias)}</span>
              </div>
            </div>
          </div>

          {/* Movements History for this register */}
          <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-2xs space-y-3">
            <h3 className="font-bold text-sm text-stone-900">
              Movimentações Avulsas de Caixa (Sangrias e Suprimentos)
            </h3>

            <div className="divide-y divide-stone-100">
              {cashMovements.length === 0 ? (
                <div className="py-8 text-center text-xs text-stone-400">
                  Nenhuma sangria ou suprimento registrado neste turno.
                </div>
              ) : (
                cashMovements.map((mov) => (
                  <div key={mov.id} className="py-2.5 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2.5">
                      <div className={`p-1.5 rounded-lg ${
                        mov.type === 'suprimento' ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'
                      }`}>
                        {mov.type === 'suprimento' ? (
                          <ArrowUpRight className="w-4 h-4" />
                        ) : (
                          <ArrowDownRight className="w-4 h-4" />
                        )}
                      </div>
                      <div>
                        <span className="font-bold text-stone-900 capitalize">{mov.type}</span>
                        <span className="text-stone-500 ml-2">· {mov.reason}</span>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className={`font-mono font-bold ${
                        mov.type === 'suprimento' ? 'text-emerald-700' : 'text-rose-700'
                      }`}>
                        {mov.type === 'suprimento' ? '+' : '-'} {formatCurrency(mov.amount)}
                      </div>
                      <div className="text-[10px] text-stone-400 font-mono">
                        {formatDateTime(mov.timestamp)} ({mov.operator})
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="py-16 text-center bg-white rounded-2xl border border-stone-200 shadow-2xs space-y-3">
          <div className="w-14 h-14 bg-stone-100 rounded-full flex items-center justify-center mx-auto text-stone-400">
            <Lock className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-stone-900">Nenhum Caixa Aberto no Momento</h3>
          <p className="text-xs text-stone-500 max-w-sm mx-auto">
            Para registrar vendas em dinheiro no balcão e controlar o fundo de troco, abra o caixa informando o valor inicial.
          </p>
          <button
            type="button"
            onClick={() => setShowOpenModal(true)}
            className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold transition-colors"
          >
            Abrir Caixa Agora
          </button>
        </div>
      )}

      {/* OPEN CASH REGISTER MODAL */}
      {showOpenModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6 space-y-4">
            <div className="flex items-center gap-2">
              <Unlock className="w-5 h-5 text-amber-600" />
              <h3 className="font-bold text-base text-stone-900">Abertura de Caixa</h3>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-stone-700">Fundo de Troco Inicial (R$):</label>
                <input
                  type="number"
                  step="1"
                  value={initialCashInput}
                  onChange={(e) => setInitialCashInput(e.target.value)}
                  className="w-full mt-1 p-2 text-xs bg-stone-50 border border-stone-200 rounded-lg focus:outline-none"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-stone-700">Observações de abertura:</label>
                <input
                  type="text"
                  value={openNotes}
                  onChange={(e) => setOpenNotes(e.target.value)}
                  placeholder="Ex: Turno almoço, moedas conferidas"
                  className="w-full mt-1 p-2 text-xs bg-stone-50 border border-stone-200 rounded-lg focus:outline-none"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowOpenModal(false)}
                className="px-3 py-2 text-xs font-medium text-stone-600 hover:bg-stone-100 rounded-lg"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleOpen}
                className="px-4 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-lg"
              >
                Confirmar Abertura
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CLOSE CASH REGISTER MODAL */}
      {showCloseModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6 space-y-4">
            <div className="flex items-center gap-2">
              <Lock className="w-5 h-5 text-stone-900" />
              <h3 className="font-bold text-base text-stone-900">Fechamento e Conferência de Caixa</h3>
            </div>

            <div className="p-3 bg-stone-50 rounded-xl space-y-1 text-xs border border-stone-200">
              <div className="flex justify-between text-stone-600">
                <span>Saldo físico esperado no sistema:</span>
                <span className="font-mono font-bold text-stone-900">{formatCurrency(expectedPhysicalCash)}</span>
              </div>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-stone-700">Valor Físico Contado na Gaveta (R$):</label>
                <input
                  type="number"
                  step="0.10"
                  value={countedCashInput}
                  onChange={(e) => setCountedCashInput(e.target.value)}
                  className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg font-mono focus:outline-none"
                />
              </div>

              {countedCashInput && (
                <div className="p-2.5 rounded-lg border text-xs">
                  {parseFloat(countedCashInput) - expectedPhysicalCash === 0 ? (
                    <span className="text-emerald-700 font-bold">✓ Caixa bateu exatamente com o sistema!</span>
                  ) : parseFloat(countedCashInput) - expectedPhysicalCash > 0 ? (
                    <span className="text-blue-700 font-bold">
                      Sobrou R$ {formatCurrency(parseFloat(countedCashInput) - expectedPhysicalCash)} na gaveta.
                    </span>
                  ) : (
                    <span className="text-rose-700 font-bold">
                      Falta R$ {formatCurrency(Math.abs(parseFloat(countedCashInput) - expectedPhysicalCash))} (quebra de caixa).
                    </span>
                  )}
                </div>
              )}

              <div>
                <label className="font-semibold text-stone-700">Observações de fechamento:</label>
                <input
                  type="text"
                  value={closeNotes}
                  onChange={(e) => setCloseNotes(e.target.value)}
                  placeholder="Ex: Turno encerrado sem divergências"
                  className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowCloseModal(false)}
                className="px-3 py-2 text-xs font-medium text-stone-600 hover:bg-stone-100 rounded-lg"
              >
                Voltar
              </button>
              <button
                type="button"
                onClick={handleClose}
                className="px-4 py-2 text-xs font-bold text-white bg-stone-900 hover:bg-stone-800 rounded-lg"
              >
                Confirmar Fechamento
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SANGRIA / SUPRIMENTO MODAL */}
      {showMovementModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6 space-y-4">
            <h3 className="font-bold text-base text-stone-900 capitalize">
              {showMovementModal === 'sangria' ? 'Sangria de Caixa (Retirada)' : 'Suprimento de Caixa (Entrada)'}
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-stone-700">Valor (R$):</label>
                <input
                  type="number"
                  step="1"
                  value={movementAmount}
                  onChange={(e) => setMovementAmount(e.target.value)}
                  placeholder="0,00"
                  className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg font-mono focus:outline-none"
                />
              </div>
              <div>
                <label className="font-semibold text-stone-700">Motivo / Justificativa:</label>
                <input
                  type="text"
                  value={movementReason}
                  onChange={(e) => setMovementReason(e.target.value)}
                  placeholder={showMovementModal === 'sangria' ? 'Ex: Envio para o cofre de segurança' : 'Ex: Troco de moedas'}
                  className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowMovementModal(null)}
                className="px-3 py-2 text-xs font-medium text-stone-600 hover:bg-stone-100 rounded-lg"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleMovement}
                className={`px-4 py-2 text-xs font-bold text-white rounded-lg ${
                  showMovementModal === 'sangria' ? 'bg-rose-600 hover:bg-rose-700' : 'bg-emerald-600 hover:bg-emerald-700'
                }`}
              >
                Confirmar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
