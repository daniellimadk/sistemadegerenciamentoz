import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import type { InventoryItem, InventoryMovementType } from '../types/index.ts';
import { formatCurrency, formatDate } from '../utils/formatters.ts';
import {
  Package,
  AlertTriangle,
  Plus,
  ArrowUpDown,
  Search,
  Filter,
  CheckCircle2,
  Calendar,
  Building2,
  FileSpreadsheet,
  XCircle,
  HelpCircle
} from 'lucide-react';

export const InventoryView: React.FC = () => {
  const {
    inventory,
    suppliers,
    registerInventoryMovement,
    createInventoryItem,
    updateInventoryItem
  } = useApp();

  const [search, setSearch] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [onlyLowStock, setOnlyLowStock] = useState(false);

  // Movement modal
  const [movingItem, setMovingItem] = useState<InventoryItem | null>(null);
  const [movementType, setMovementType] = useState<InventoryMovementType>('entrada');
  const [movementQty, setMovementQty] = useState('');
  const [movementReason, setMovementReason] = useState('');

  // Create new item modal
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newItemData, setNewItemData] = useState<Partial<InventoryItem>>({
    code: 'ING-' + Math.floor(100 + Math.random() * 900),
    name: '',
    category: 'Secos',
    unit: 'kg',
    currentQuantity: 10,
    minQuantity: 5,
    unitCost: 10.00,
    storageLocation: 'Despensa'
  });

  const categories = Array.from(new Set(inventory.map(i => i.category)));

  const filteredInventory = inventory.filter((item) => {
    const matchesSearch =
      item.name.toLowerCase().includes(search.toLowerCase()) ||
      item.code.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = filterCategory === 'all' || item.category === filterCategory;
    const matchesLowStock = !onlyLowStock || item.currentQuantity <= item.minQuantity;
    return matchesSearch && matchesCategory && matchesLowStock;
  });

  const lowStockCount = inventory.filter(i => i.currentQuantity <= i.minQuantity).length;
  const totalInventoryValue = inventory.reduce((acc, i) => acc + (i.currentQuantity * i.unitCost), 0);

  const handleConfirmMovement = async () => {
    if (!movingItem) return;
    const qty = parseFloat(movementQty) || 0;
    if (qty <= 0) return;

    await registerInventoryMovement({
      itemId: movingItem.id,
      type: movementType,
      quantity: qty,
      reason: movementReason || 'Ajuste operacional manual',
      unitCost: movingItem.unitCost
    });

    setMovingItem(null);
    setMovementQty('');
    setMovementReason('');
  };

  const handleCreateItem = async () => {
    if (!newItemData.name) return;
    await createInventoryItem(newItemData);
    setShowCreateModal(false);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Page Title & Metrics */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-stone-900">
            Estoque Inteligente & Fichas Técnicas
          </h1>
          <p className="text-xs sm:text-sm text-stone-500 mt-0.5">
            Baixa automática integrada aos pedidos da cozinha e controle de perdas.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-1.5 px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Cadastrar Novo Insumo</span>
        </button>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-2xs">
          <span className="text-xs text-stone-500 font-medium">Valor Total em Estoque (Custo)</span>
          <div className="text-2xl font-bold text-stone-900 font-mono mt-2">
            {formatCurrency(totalInventoryValue)}
          </div>
          <div className="text-[11px] text-stone-500 mt-1">
            Total de {inventory.length} insumos monitorados
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-2xs">
          <span className="text-xs text-stone-500 font-medium">Itens em Estoque Mínimo / Crítico</span>
          <div className="text-2xl font-bold text-rose-700 font-mono mt-2">
            {lowStockCount} {lowStockCount === 1 ? 'insumo' : 'insumos'}
          </div>
          <div className="text-[11px] text-rose-600 mt-1">
            Necessitam de pedido de reposição aos fornecedores
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-2xs">
          <span className="text-xs text-stone-500 font-medium">Automação de Ficha Técnica</span>
          <div className="text-2xl font-bold text-emerald-700 font-mono mt-2">
            Ativa
          </div>
          <div className="text-[11px] text-stone-500 mt-1">
            Dedução em tempo real a cada lanche confirmado
          </div>
        </div>
      </div>

      {/* Search & Filter Controls */}
      <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-2xs flex flex-wrap items-center gap-3">
        <div className="flex-1 min-w-[240px] relative">
          <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar por nome do insumo ou código (ex: Blend, Pão, ING-001)..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500"
          />
        </div>

        <div className="flex items-center gap-1.5">
          <span className="text-xs text-stone-500">Categoria:</span>
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="text-xs bg-stone-50 border border-stone-200 rounded-lg px-2.5 py-2 focus:outline-none"
          >
            <option value="all">Todas as Categorias</option>
            {categories.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>

        <button
          type="button"
          onClick={() => setOnlyLowStock(!onlyLowStock)}
          className={`px-3 py-2 text-xs font-semibold rounded-lg border transition-colors flex items-center gap-1.5 ${
            onlyLowStock
              ? 'bg-rose-50 border-rose-300 text-rose-700'
              : 'bg-stone-50 border-stone-200 text-stone-600 hover:bg-stone-100'
          }`}
        >
          <AlertTriangle className="w-3.5 h-3.5" />
          <span>Apenas Estoque Baixo ({lowStockCount})</span>
        </button>
      </div>

      {/* Inventory Table */}
      <div className="bg-white rounded-xl border border-stone-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-stone-50 border-b border-stone-200 text-stone-600 font-semibold uppercase tracking-wider text-[10px]">
              <tr>
                <th className="py-3 px-4">Código</th>
                <th className="py-3 px-4">Insumo</th>
                <th className="py-3 px-4">Categoria</th>
                <th className="py-3 px-4">Estoque Atual</th>
                <th className="py-3 px-4">Estoque Mín.</th>
                <th className="py-3 px-4">Custo Unit.</th>
                <th className="py-3 px-4">Fornecedor</th>
                <th className="py-3 px-4">Validade</th>
                <th className="py-3 px-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {filteredInventory.map((item) => {
                const isLow = item.currentQuantity <= item.minQuantity;

                return (
                  <tr key={item.id} className="hover:bg-stone-50/80 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-stone-600">
                      {item.code}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-stone-900">{item.name}</div>
                      <div className="text-[11px] text-stone-500">{item.storageLocation || 'Despensa'}</div>
                    </td>
                    <td className="py-3 px-4 text-stone-600">
                      {item.category}
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <span className={`font-mono font-bold text-sm ${
                          isLow ? 'text-rose-600' : 'text-stone-900'
                        }`}>
                          {item.currentQuantity} {item.unit}
                        </span>
                        {isLow && (
                          <span className="text-[10px] bg-rose-100 text-rose-800 font-bold px-1.5 py-0.5 rounded-sm">
                            BAIXO
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono text-stone-500">
                      {item.minQuantity} {item.unit}
                    </td>
                    <td className="py-3 px-4 font-mono text-stone-800">
                      {formatCurrency(item.unitCost)} / {item.unit}
                    </td>
                    <td className="py-3 px-4 text-stone-600">
                      {item.supplierName || 'Geral'}
                    </td>
                    <td className="py-3 px-4 font-mono text-stone-500">
                      {item.expirationDate ? formatDate(item.expirationDate) : '—'}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        type="button"
                        onClick={() => setMovingItem(item)}
                        className="px-2.5 py-1 text-[11px] font-semibold text-amber-700 bg-amber-50 hover:bg-amber-100 rounded-md border border-amber-200 transition-colors"
                      >
                        Movimentar
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* MOVEMENT MODAL */}
      {movingItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6 space-y-4">
            <div>
              <h3 className="font-bold text-base text-stone-900">
                Movimentação Manual de Estoque
              </h3>
              <p className="text-xs text-stone-500 mt-0.5">
                {movingItem.name} ({movingItem.code}) · Saldo atual: <strong>{movingItem.currentQuantity} {movingItem.unit}</strong>
              </p>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-stone-700">Tipo de Movimentação:</label>
                <select
                  value={movementType}
                  onChange={(e) => setMovementType(e.target.value as InventoryMovementType)}
                  className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none"
                >
                  <option value="entrada">Entrada / Compra de Mercadoria (+)</option>
                  <option value="saida_manual">Saída Manual / Transferência (-)</option>
                  <option value="perda_desperdicio">Perda / Desperdício / Quebra (-)</option>
                  <option value="vencido">Produto Vencido / Descarte (-)</option>
                  <option value="ajuste_inventario">Ajuste de Balanço / Inventário (=)</option>
                </select>
              </div>

              <div>
                <label className="font-semibold text-stone-700">
                  Quantidade ({movingItem.unit}):
                </label>
                <input
                  type="number"
                  step="0.1"
                  min="0.1"
                  value={movementQty}
                  onChange={(e) => setMovementQty(e.target.value)}
                  placeholder={`Ex: 5 ${movingItem.unit}`}
                  className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg font-mono focus:outline-none"
                />
              </div>

              <div>
                <label className="font-semibold text-stone-700">Justificativa / Motivo:</label>
                <input
                  type="text"
                  value={movementReason}
                  onChange={(e) => setMovementReason(e.target.value)}
                  placeholder="Ex: Nota Fiscal 1234, descarte por prazo de validade..."
                  className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-stone-100">
              <button
                type="button"
                onClick={() => setMovingItem(null)}
                className="px-3 py-2 text-xs font-medium text-stone-600 hover:bg-stone-100 rounded-lg"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleConfirmMovement}
                className="px-4 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-lg"
              >
                Gravar Movimentação
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CREATE INVENTORY ITEM MODAL */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full p-6 space-y-4">
            <h3 className="font-bold text-base text-stone-900">
              Cadastrar Novo Insumo no Estoque
            </h3>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="font-semibold text-stone-700">Código:</label>
                <input
                  type="text"
                  value={newItemData.code}
                  onChange={(e) => setNewItemData({ ...newItemData, code: e.target.value })}
                  className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg font-mono"
                />
              </div>
              <div>
                <label className="font-semibold text-stone-700">Nome do Insumo:</label>
                <input
                  type="text"
                  value={newItemData.name}
                  onChange={(e) => setNewItemData({ ...newItemData, name: e.target.value })}
                  placeholder="Ex: Queijo Gorgonzola"
                  className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg"
                />
              </div>
              <div>
                <label className="font-semibold text-stone-700">Categoria:</label>
                <input
                  type="text"
                  value={newItemData.category}
                  onChange={(e) => setNewItemData({ ...newItemData, category: e.target.value })}
                  placeholder="Ex: Laticínios"
                  className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg"
                />
              </div>
              <div>
                <label className="font-semibold text-stone-700">Unidade de Medida:</label>
                <select
                  value={newItemData.unit}
                  onChange={(e) => setNewItemData({ ...newItemData, unit: e.target.value as any })}
                  className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg"
                >
                  <option value="un">Unidade (un)</option>
                  <option value="kg">Quilograma (kg)</option>
                  <option value="g">Grama (g)</option>
                  <option value="l">Litro (l)</option>
                  <option value="ml">Mililitro (ml)</option>
                </select>
              </div>
              <div>
                <label className="font-semibold text-stone-700">Quantidade Inicial:</label>
                <input
                  type="number"
                  step="0.1"
                  value={newItemData.currentQuantity}
                  onChange={(e) => setNewItemData({ ...newItemData, currentQuantity: parseFloat(e.target.value) || 0 })}
                  className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg font-mono"
                />
              </div>
              <div>
                <label className="font-semibold text-stone-700">Estoque Mínimo:</label>
                <input
                  type="number"
                  step="0.1"
                  value={newItemData.minQuantity}
                  onChange={(e) => setNewItemData({ ...newItemData, minQuantity: parseFloat(e.target.value) || 0 })}
                  className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg font-mono"
                />
              </div>
              <div>
                <label className="font-semibold text-stone-700">Custo Unitário (R$):</label>
                <input
                  type="number"
                  step="0.5"
                  value={newItemData.unitCost}
                  onChange={(e) => setNewItemData({ ...newItemData, unitCost: parseFloat(e.target.value) || 0 })}
                  className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg font-mono"
                />
              </div>
              <div>
                <label className="font-semibold text-stone-700">Fornecedor Principal:</label>
                <select
                  value={newItemData.supplierId || ''}
                  onChange={(e) => {
                    const sup = suppliers.find(s => s.id === e.target.value);
                    setNewItemData({
                      ...newItemData,
                      supplierId: e.target.value,
                      supplierName: sup ? sup.name : undefined
                    });
                  }}
                  className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg"
                >
                  <option value="">Selecione o fornecedor</option>
                  {suppliers.map(s => (
                    <option key={s.id} value={s.id}>{s.name}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-stone-100">
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="px-3 py-2 text-xs font-medium text-stone-600 hover:bg-stone-100 rounded-lg"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleCreateItem}
                className="px-4 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-lg"
              >
                Salvar Insumo
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
