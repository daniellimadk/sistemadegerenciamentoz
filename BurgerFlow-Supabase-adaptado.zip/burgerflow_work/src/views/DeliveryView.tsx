import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import type { Courier, DeliveryNeighborhood } from '../types/index.ts';
import { formatCurrency, formatDateTime } from '../utils/formatters.ts';
import {
  Truck,
  Plus,
  Phone,
  CheckCircle2,
  MapPin,
  Clock,
  User,
  Shield,
  Navigation,
  RotateCcw
} from 'lucide-react';

export const DeliveryView: React.FC = () => {
  const {
    couriers,
    orders,
    settings,
    updateSettings,
    updateOrderStatus
  } = useApp();

  const [newCourierName, setNewCourierName] = useState('');
  const [newCourierPhone, setNewCourierPhone] = useState('');
  const [newCourierVehicle, setNewCourierVehicle] = useState<'moto' | 'bicicleta' | 'carro'>('moto');

  const [newNeighborhood, setNewNeighborhood] = useState('');
  const [newFee, setNewFee] = useState('7.00');
  const [newEstTime, setNewEstTime] = useState('25');

  // Delivery orders currently out or ready for delivery
  const deliveryOrders = orders.filter(o => o.orderType === 'delivery');
  const activeDeliveries = deliveryOrders.filter(o => o.status === 'saiu_entrega' || o.status === 'pronto');

  // Takeaway orders ready for customer pickup
  const readyTakeawayOrders = orders.filter(
    o => (o.orderType === 'balcao' || o.orderType === 'retirada' || o.orderType === 'mesa') && o.status === 'pronto'
  );

  const handleAddNeighborhood = () => {
    if (!newNeighborhood) return;
    const current = settings.deliveryNeighborhoods || [];
    const updated: DeliveryNeighborhood[] = [
      ...current,
      {
        name: newNeighborhood,
        fee: parseFloat(newFee) || 0,
        estimatedMinutes: parseInt(newEstTime) || 30
      }
    ];
    updateSettings({ deliveryNeighborhoods: updated });
    setNewNeighborhood('');
  };

  const handleRemoveNeighborhood = (name: string) => {
    const updated = (settings.deliveryNeighborhoods || []).filter(n => n.name !== name);
    updateSettings({ deliveryNeighborhoods: updated });
  };

  const handleAssignCourier = async (orderId: string, courierId: string) => {
    const courier = couriers.find(c => c.id === courierId);
    if (!courier) return;
    await updateOrderStatus(orderId, 'saiu_entrega', undefined, courier.id, courier.name);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-stone-900">
            Logística de Delivery & Retirada Balcão
          </h1>
          <p className="text-xs sm:text-sm text-stone-500 mt-0.5">
            Gestão de motoboys, despacho de entregas e painel de chamada de senhas.
          </p>
        </div>
      </div>

      {/* Screen Split: Active Deliveries & Pickup Counter Calling */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Active Out-for-Delivery Orders */}
        <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-2xs space-y-4">
          <div className="flex items-center justify-between border-b border-stone-100 pb-3">
            <h3 className="font-bold text-sm text-stone-900 flex items-center gap-2">
              <Truck className="w-4 h-4 text-indigo-600" />
              Entregas em Rota / Aguardando Motoboy
            </h3>
            <span className="text-xs font-semibold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">
              {activeDeliveries.length} ativas
            </span>
          </div>

          <div className="space-y-3">
            {activeDeliveries.length === 0 ? (
              <div className="py-12 text-center text-xs text-stone-400">
                Nenhum pedido de delivery em rota no momento.
              </div>
            ) : (
              activeDeliveries.map((order) => (
                <div
                  key={order.id}
                  className="p-3.5 rounded-xl border border-stone-200 bg-stone-50/60 space-y-2.5"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-stone-900 text-sm">
                      Pedido #{order.orderNumber}
                    </span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      order.status === 'saiu_entrega'
                        ? 'bg-indigo-100 text-indigo-800'
                        : 'bg-purple-100 text-purple-800'
                    }`}>
                      {order.status === 'saiu_entrega' ? 'EM ROTA' : 'PRONTO NA COZINHA'}
                    </span>
                  </div>

                  <div className="text-xs text-stone-700">
                    <div>Cliente: <strong>{order.customerName}</strong> ({order.customerPhone})</div>
                    {order.customerAddress && (
                      <div className="text-stone-500 flex items-center gap-1 mt-0.5">
                        <MapPin className="w-3.5 h-3.5 shrink-0" />
                        <span>
                          {order.customerAddress.street}, {order.customerAddress.number} - {order.customerAddress.neighborhood}
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="pt-2 border-t border-stone-200 flex items-center justify-between gap-2">
                    {order.status === 'pronto' ? (
                      <div className="flex items-center gap-2 w-full">
                        <select
                          id={`courier-${order.id}`}
                          defaultValue=""
                          className="flex-1 text-xs bg-white border border-stone-300 rounded-lg p-1.5 focus:outline-none"
                        >
                          <option value="" disabled>Selecione o Entregador</option>
                          {couriers.map(c => (
                            <option key={c.id} value={c.id}>{c.name}</option>
                          ))}
                        </select>
                        <button
                          type="button"
                          onClick={() => {
                            const sel = (document.getElementById(`courier-${order.id}`) as HTMLSelectElement)?.value;
                            if (sel) handleAssignCourier(order.id, sel);
                          }}
                          className="px-3 py-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors whitespace-nowrap"
                        >
                          Despachar
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center justify-between w-full">
                        <span className="text-xs text-indigo-700 font-semibold">
                          Entregador: {order.courierName || 'Carlos (Moto)'}
                        </span>
                        <button
                          type="button"
                          onClick={() => updateOrderStatus(order.id, 'entregue')}
                          className="px-3 py-1 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors"
                        >
                          Confirmar Entrega
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Pickup Counter Board (Painel de Senhas Prontas) */}
        <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-2xs space-y-4">
          <div className="flex items-center justify-between border-b border-stone-100 pb-3">
            <h3 className="font-bold text-sm text-stone-900 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              Painel de Chamada de Senhas (Retirada / Balcão)
            </h3>
            <span className="text-xs text-stone-400">Prontos p/ cliente</span>
          </div>

          <div className="space-y-3">
            {readyTakeawayOrders.length === 0 ? (
              <div className="py-12 text-center text-xs text-stone-400">
                Nenhum pedido aguardando retirada no balcão neste instante.
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                {readyTakeawayOrders.map((ro) => (
                  <div
                    key={ro.id}
                    className="p-4 bg-emerald-50/70 border-2 border-emerald-300 rounded-xl text-center space-y-1.5"
                  >
                    <div className="text-[11px] font-bold text-emerald-800 uppercase">
                      SENHA PRONTA
                    </div>
                    <div className="font-mono text-2xl font-black text-emerald-950">
                      #{ro.orderNumber}
                    </div>
                    <div className="text-xs text-stone-700 truncate font-semibold">
                      {ro.customerName}
                    </div>
                    <button
                      type="button"
                      onClick={() => updateOrderStatus(ro.id, 'entregue')}
                      className="w-full mt-2 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold transition-colors"
                    >
                      Entregue ao Cliente
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Couriers List & Neighborhoods Management */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Couriers Management */}
        <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-2xs space-y-4">
          <h3 className="font-bold text-sm text-stone-900">
            Entregadores Cadastrados
          </h3>

          <div className="divide-y divide-stone-100">
            {couriers.map((c) => (
              <div key={c.id} className="py-3 flex items-center justify-between text-xs">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-stone-100 flex items-center justify-center text-stone-700 font-bold">
                    <Truck className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-semibold text-stone-900">{c.name}</div>
                    <div className="text-[11px] text-stone-500">
                      {c.phone} · Veículo: <strong className="capitalize">{c.vehicle}</strong> ({c.plate || 'S/ placa'})
                    </div>
                  </div>
                </div>

                <span className="text-[11px] text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                  Disponível
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Neighborhoods and Delivery Rates */}
        <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-2xs space-y-4">
          <h3 className="font-bold text-sm text-stone-900">
            Bairros Atendidos & Taxas de Entrega
          </h3>

          <div className="flex gap-2 text-xs">
            <input
              type="text"
              value={newNeighborhood}
              onChange={(e) => setNewNeighborhood(e.target.value)}
              placeholder="Nome do Bairro (ex: Pinheiros)"
              className="flex-1 p-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none"
            />
            <input
              type="number"
              step="0.5"
              value={newFee}
              onChange={(e) => setNewFee(e.target.value)}
              placeholder="Taxa R$"
              className="w-20 p-2 bg-stone-50 border border-stone-200 rounded-lg font-mono focus:outline-none"
            />
            <button
              type="button"
              onClick={handleAddNeighborhood}
              className="px-3 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-semibold transition-colors shrink-0"
            >
              Adicionar
            </button>
          </div>

          <div className="max-h-60 overflow-y-auto divide-y divide-stone-100">
            {(settings.deliveryNeighborhoods || []).map((n) => (
              <div key={n.name} className="py-2.5 flex items-center justify-between text-xs">
                <div>
                  <span className="font-semibold text-stone-800">{n.name}</span>
                  <span className="text-stone-400 text-[11px] ml-2">~{n.estimatedMinutes} min</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-mono font-bold text-stone-900">
                    {formatCurrency(n.fee)}
                  </span>
                  <button
                    type="button"
                    onClick={() => handleRemoveNeighborhood(n.name)}
                    className="text-stone-400 hover:text-rose-600 p-1"
                  >
                    &times;
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
