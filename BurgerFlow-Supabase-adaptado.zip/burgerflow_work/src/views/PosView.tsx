import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import type { Product, OrderItem, OrderType, PaymentMethod, Order } from '../types/index.ts';
import { formatCurrency, PAYMENT_METHOD_LABELS } from '../utils/formatters.ts';
import { ReceiptModal } from '../components/ReceiptModal.tsx';
import {
  Search,
  ShoppingCart,
  Trash2,
  Plus,
  Minus,
  CheckCircle2,
  DollarSign,
  Printer,
  User,
  CreditCard,
  QrCode,
  Banknote,
  Utensils,
  Percent,
  X
} from 'lucide-react';

export const PosView: React.FC = () => {
  const {
    products,
    categories,
    createOrder,
    cashRegister,
    settings,
    openCashRegister
  } = useApp();

  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // POS Cart State
  const [cartItems, setCartItems] = useState<OrderItem[]>([]);
  const [customerName, setCustomerName] = useState('Cliente Balcão');
  const [customerPhone, setCustomerPhone] = useState('(11) 99999-0000');
  const [orderType, setOrderType] = useState<OrderType>('balcao');
  const [tableNumber, setTableNumber] = useState('');
  const [discount, setDiscount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('dinheiro');
  const [cashTendered, setCashTendered] = useState<string>('');

  // Customization modal for adding product with specific add-ons
  const [customizingProduct, setCustomizingProduct] = useState<Product | null>(null);
  const [selectedAddons, setSelectedAddons] = useState<Array<{ id: string; name: string; price: number }>>([]);
  const [selectedRemovals, setSelectedRemovals] = useState<string[]>([]);
  const [itemNotes, setItemNotes] = useState('');

  // Receipt modal after sale
  const [lastFinishedOrder, setLastFinishedOrder] = useState<Order | null>(null);

  // Subtotal & Calculations
  const subtotal = cartItems.reduce((acc, item) => acc + item.totalPrice, 0);
  const total = Math.max(0, subtotal - discount);
  const tenderedNum = parseFloat(cashTendered) || 0;
  const changeDue = Math.max(0, tenderedNum - total);

  // Filter products
  const filteredProducts = products.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.code.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || p.categoryId === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleOpenCustomize = (product: Product) => {
    setCustomizingProduct(product);
    setSelectedAddons([]);
    setSelectedRemovals([]);
    setItemNotes('');
  };

  const handleAddDirect = (product: Product) => {
    const existingIndex = cartItems.findIndex(
      (item) => item.productId === product.id && (!item.addOns || item.addOns.length === 0) && (!item.removedIngredients || item.removedIngredients.length === 0) && !item.notes
    );

    if (existingIndex >= 0) {
      const updated = [...cartItems];
      updated[existingIndex].quantity += 1;
      updated[existingIndex].totalPrice = updated[existingIndex].quantity * product.price;
      setCartItems(updated);
    } else {
      const newItem: OrderItem = {
        id: 'item-' + Date.now() + Math.random().toString(36).substring(2, 5),
        productId: product.id,
        productName: product.name,
        quantity: 1,
        unitPrice: product.price,
        addOns: [],
        removedIngredients: [],
        totalPrice: product.price
      };
      setCartItems([...cartItems, newItem]);
    }
  };

  const handleConfirmCustomize = () => {
    if (!customizingProduct) return;
    const addOnTotal = selectedAddons.reduce((acc, a) => acc + a.price, 0);
    const itemUnitPrice = customizingProduct.price + addOnTotal;

    const newItem: OrderItem = {
      id: 'item-' + Date.now() + Math.random().toString(36).substring(2, 5),
      productId: customizingProduct.id,
      productName: customizingProduct.name,
      quantity: 1,
      unitPrice: itemUnitPrice,
      addOns: selectedAddons,
      removedIngredients: selectedRemovals,
      notes: itemNotes,
      totalPrice: itemUnitPrice
    };

    setCartItems([...cartItems, newItem]);
    setCustomizingProduct(null);
  };

  const handleUpdateQuantity = (index: number, delta: number) => {
    const updated = [...cartItems];
    const newQty = updated[index].quantity + delta;
    if (newQty <= 0) {
      updated.splice(index, 1);
    } else {
      updated[index].quantity = newQty;
      const basePrice = updated[index].unitPrice;
      updated[index].totalPrice = basePrice * newQty;
    }
    setCartItems(updated);
  };

  const handleClearCart = () => {
    setCartItems([]);
    setDiscount(0);
    setCashTendered('');
  };

  const handleFinishSale = async () => {
    if (cartItems.length === 0) return;

    try {
      const orderData: Partial<Order> = {
        customerName: customerName || 'Cliente Balcão',
        customerPhone: customerPhone || '(11) 99999-0000',
        orderType,
        tableNumber: orderType === 'mesa' ? tableNumber : undefined,
        items: cartItems,
        subtotal,
        deliveryFee: 0,
        discount,
        total,
        paymentMethod,
        paymentStatus: 'pago',
        changeFor: paymentMethod === 'dinheiro' && tenderedNum > total ? tenderedNum : undefined,
        estimatedPrepMinutes: 15,
        status: 'em_preparacao'
      };

      const created = await createOrder(orderData);
      setLastFinishedOrder(created);
      handleClearCart();
    } catch (e) {
      console.error('Erro ao finalizar venda:', e);
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-4">
      {/* Cash Register banner check */}
      {!cashRegister && (
        <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl flex items-center justify-between">
          <div className="text-xs text-amber-900 font-medium">
            ⚠️ <strong>Atenção:</strong> O caixa está fechado no momento. As vendas presenciais não somarão ao saldo físico até que você abra o caixa.
          </div>
          <button
            type="button"
            onClick={() => openCashRegister(150, 'Abertura rápida pelo PDV')}
            className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold transition-colors"
          >
            Abrir Caixa Agora (R$ 150)
          </button>
        </div>
      )}

      {/* Main PDV split screen */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* LEFT COLUMN: Catalog (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          {/* Search & Categories Bar */}
          <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-2xs space-y-3">
            <div className="relative">
              <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Pesquisar produto pelo nome ou código..."
                className="w-full pl-9 pr-3 py-2 text-xs bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500"
              />
            </div>

            {/* Category tabs */}
            <div className="flex gap-1.5 overflow-x-auto pb-1">
              <button
                type="button"
                onClick={() => setSelectedCategory('all')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                  selectedCategory === 'all'
                    ? 'bg-amber-600 text-white shadow-2xs'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                }`}
              >
                Todos
              </button>
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                    selectedCategory === cat.id
                      ? 'bg-amber-600 text-white shadow-2xs'
                      : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                  }`}
                >
                  {cat.name}
                </button>
              ))}
            </div>
          </div>

          {/* Product Cards Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 max-h-[600px] overflow-y-auto pr-1">
            {filteredProducts.map((product) => (
              <div
                key={product.id}
                className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-2xs hover:shadow-sm transition-shadow flex flex-col justify-between"
              >
                <div className="relative h-28 bg-stone-100 overflow-hidden">
                  <img
                    src={product.imageUrl}
                    alt={product.name}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  {!product.available && (
                    <div className="absolute inset-0 bg-black/60 flex items-center justify-center text-white text-[10px] font-bold uppercase tracking-wider">
                      Esgotado
                    </div>
                  )}
                  <span className="absolute bottom-1 right-1 bg-stone-900/80 text-white text-[10px] px-1.5 py-0.5 rounded-sm font-mono">
                    {product.code}
                  </span>
                </div>

                <div className="p-3 flex-1 flex flex-col justify-between space-y-2">
                  <div>
                    <h3 className="font-semibold text-stone-900 text-xs line-clamp-1">
                      {product.name}
                    </h3>
                    <p className="text-[11px] text-stone-500 line-clamp-2 mt-0.5 leading-snug">
                      {product.description}
                    </p>
                  </div>

                  <div className="pt-2 border-t border-stone-100 flex items-center justify-between gap-1">
                    <span className="font-mono font-bold text-stone-900 text-xs">
                      {formatCurrency(product.price)}
                    </span>

                    <div className="flex items-center gap-1">
                      {product.addOns && product.addOns.length > 0 ? (
                        <button
                          type="button"
                          disabled={!product.available}
                          onClick={() => handleOpenCustomize(product)}
                          className="px-2 py-1 bg-amber-50 text-amber-700 hover:bg-amber-100 rounded-md text-[11px] font-bold border border-amber-200 disabled:opacity-50"
                        >
                          Personalizar
                        </button>
                      ) : (
                        <button
                          type="button"
                          disabled={!product.available}
                          onClick={() => handleAddDirect(product)}
                          className="p-1 bg-amber-600 hover:bg-amber-700 text-white rounded-md disabled:opacity-50"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* RIGHT COLUMN: POS Cart & Checkout (5 cols) */}
        <div className="lg:col-span-5 bg-white rounded-xl border border-stone-200 shadow-2xs p-5 space-y-4 sticky top-20">
          <div className="flex items-center justify-between border-b border-stone-100 pb-3">
            <div className="flex items-center gap-2">
              <ShoppingCart className="w-5 h-5 text-amber-600" />
              <h2 className="font-bold text-sm text-stone-900">Comanda da Venda</h2>
            </div>
            {cartItems.length > 0 && (
              <button
                type="button"
                onClick={handleClearCart}
                className="text-xs text-rose-600 hover:underline flex items-center gap-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Limpar
              </button>
            )}
          </div>

          {/* Type & Table */}
          <div className="grid grid-cols-3 gap-1 bg-stone-100 p-1 rounded-lg">
            {(['balcao', 'mesa', 'retirada'] as OrderType[]).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setOrderType(t)}
                className={`py-1 text-xs font-semibold rounded-md capitalize transition-colors ${
                  orderType === t ? 'bg-white text-stone-900 shadow-2xs' : 'text-stone-500'
                }`}
              >
                {t}
              </button>
            ))}
          </div>

          {orderType === 'mesa' && (
            <input
              type="text"
              value={tableNumber}
              onChange={(e) => setTableNumber(e.target.value)}
              placeholder="Número da Mesa (ex: Mesa 05)"
              className="w-full p-2 text-xs bg-stone-50 border border-stone-200 rounded-lg focus:outline-none"
            />
          )}

          {/* Cart items list */}
          <div className="max-h-60 overflow-y-auto divide-y divide-stone-100 pr-1">
            {cartItems.length === 0 ? (
              <div className="py-12 text-center text-stone-400 text-xs">
                Nenhum item adicionado à comanda.
              </div>
            ) : (
              cartItems.map((item, idx) => (
                <div key={idx} className="py-2.5 flex items-start justify-between gap-2 text-xs">
                  <div className="space-y-0.5 flex-1 min-w-0">
                    <div className="font-semibold text-stone-900 truncate">
                      {item.productName}
                    </div>
                    {item.addOns && item.addOns.length > 0 && (
                      <div className="text-[10px] text-stone-500">
                        {item.addOns.map(a => `+ ${a.name}`).join(', ')}
                      </div>
                    )}
                    {item.removedIngredients && item.removedIngredients.length > 0 && (
                      <div className="text-[10px] text-rose-600">
                        Sem: {item.removedIngredients.join(', ')}
                      </div>
                    )}
                    <div className="font-mono text-stone-500 text-[11px]">
                      {formatCurrency(item.unitPrice)} cada
                    </div>
                  </div>

                  {/* Quantity adjustment & Total */}
                  <div className="flex flex-col items-end gap-1.5 shrink-0">
                    <div className="flex items-center border border-stone-200 rounded-md bg-stone-50">
                      <button
                        type="button"
                        onClick={() => handleUpdateQuantity(idx, -1)}
                        className="p-1 text-stone-600 hover:text-stone-900"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="px-2 font-mono font-bold text-xs">
                        {item.quantity}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleUpdateQuantity(idx, 1)}
                        className="p-1 text-stone-600 hover:text-stone-900"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    <span className="font-mono font-bold text-stone-900">
                      {formatCurrency(item.totalPrice)}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Subtotal, Discount & Total */}
          <div className="pt-3 border-t border-stone-100 space-y-2 text-xs">
            <div className="flex justify-between text-stone-600">
              <span>Subtotal:</span>
              <span className="font-mono font-medium">{formatCurrency(subtotal)}</span>
            </div>

            <div className="flex items-center justify-between gap-2">
              <span className="text-stone-600 flex items-center gap-1">
                <Percent className="w-3.5 h-3.5" /> Desconto (R$):
              </span>
              <input
                type="number"
                min="0"
                step="0.5"
                value={discount || ''}
                onChange={(e) => setDiscount(Math.max(0, parseFloat(e.target.value) || 0))}
                className="w-20 p-1 text-right text-xs bg-stone-50 border border-stone-200 rounded-md focus:outline-none"
                placeholder="0,00"
              />
            </div>

            <div className="flex justify-between text-base font-bold text-stone-900 pt-2 border-t border-stone-200">
              <span>Total a Pagar:</span>
              <span className="font-mono text-amber-600 text-lg">{formatCurrency(total)}</span>
            </div>
          </div>

          {/* Payment Method Selector */}
          <div className="space-y-2 pt-2 border-t border-stone-100">
            <label className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider">
              Forma de Pagamento
            </label>
            <div className="grid grid-cols-2 gap-1.5">
              {(['dinheiro', 'pix', 'cartao_credito', 'cartao_debito'] as PaymentMethod[]).map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setPaymentMethod(m)}
                  className={`p-2 rounded-lg text-xs font-semibold border flex items-center justify-center gap-1.5 transition-colors ${
                    paymentMethod === m
                      ? 'border-amber-600 bg-amber-50 text-amber-900'
                      : 'border-stone-200 bg-stone-50 text-stone-700 hover:bg-stone-100'
                  }`}
                >
                  {m === 'dinheiro' && <Banknote className="w-3.5 h-3.5" />}
                  {m === 'pix' && <QrCode className="w-3.5 h-3.5" />}
                  {m.includes('cartao') && <CreditCard className="w-3.5 h-3.5" />}
                  <span>{PAYMENT_METHOD_LABELS[m]}</span>
                </button>
              ))}
            </div>

            {/* Change calculation for Cash */}
            {paymentMethod === 'dinheiro' && (
              <div className="p-3 bg-stone-50 rounded-lg border border-stone-200 space-y-2 mt-2">
                <div className="flex items-center justify-between text-xs">
                  <span>Valor entregue pelo cliente:</span>
                  <input
                    type="number"
                    min="0"
                    step="1"
                    value={cashTendered}
                    onChange={(e) => setCashTendered(e.target.value)}
                    placeholder="R$ 0,00"
                    className="w-24 p-1.5 text-right font-mono text-xs bg-white border border-stone-300 rounded-md focus:outline-none"
                  />
                </div>
                {tenderedNum >= total && (
                  <div className="flex justify-between text-xs font-bold text-emerald-700 pt-1 border-t border-stone-200">
                    <span>Troco a devolver:</span>
                    <span className="font-mono text-sm">{formatCurrency(changeDue)}</span>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Finish Sale Button */}
          <button
            type="button"
            disabled={cartItems.length === 0}
            onClick={handleFinishSale}
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl text-sm font-bold shadow-sm transition-colors flex items-center justify-center gap-2"
          >
            <CheckCircle2 className="w-5 h-5" />
            <span>Finalizar Venda ({formatCurrency(total)})</span>
          </button>
        </div>
      </div>

      {/* Product Customization Modal */}
      {customizingProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-5 space-y-4">
            <div className="flex items-start justify-between border-b border-stone-100 pb-3">
              <div>
                <h3 className="font-bold text-sm text-stone-900">{customizingProduct.name}</h3>
                <p className="text-xs text-stone-500 font-mono">{formatCurrency(customizingProduct.price)}</p>
              </div>
              <button
                type="button"
                onClick={() => setCustomizingProduct(null)}
                className="text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Addons Selection */}
            {customizingProduct.addOns && customizingProduct.addOns.length > 0 && (
              <div className="space-y-2">
                <label className="text-xs font-bold text-stone-800">Adicionais Desejados:</label>
                <div className="space-y-1.5">
                  {customizingProduct.addOns.map((add) => {
                    const isSelected = selectedAddons.some(a => a.id === add.id);
                    return (
                      <button
                        key={add.id}
                        type="button"
                        onClick={() => {
                          if (isSelected) {
                            setSelectedAddons(selectedAddons.filter(a => a.id !== add.id));
                          } else {
                            setSelectedAddons([...selectedAddons, add]);
                          }
                        }}
                        className={`w-full p-2 rounded-lg text-xs flex items-center justify-between border transition-colors ${
                          isSelected
                            ? 'border-amber-600 bg-amber-50 text-amber-900 font-semibold'
                            : 'border-stone-200 bg-stone-50 text-stone-700'
                        }`}
                      >
                        <span>{add.name}</span>
                        <span className="font-mono text-stone-500">+{formatCurrency(add.price)}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Removals Selection */}
            {customizingProduct.removableIngredients && customizingProduct.removableIngredients.length > 0 && (
              <div className="space-y-2">
                <label className="text-xs font-bold text-stone-800">Remover Ingredientes:</label>
                <div className="flex flex-wrap gap-1.5">
                  {customizingProduct.removableIngredients.map((ing) => {
                    const isRemoved = selectedRemovals.includes(ing);
                    return (
                      <button
                        key={ing}
                        type="button"
                        onClick={() => {
                          if (isRemoved) {
                            setSelectedRemovals(selectedRemovals.filter(r => r !== ing));
                          } else {
                            setSelectedRemovals([...selectedRemovals, ing]);
                          }
                        }}
                        className={`px-2.5 py-1 rounded-md text-xs font-medium border transition-colors ${
                          isRemoved
                            ? 'bg-rose-50 border-rose-300 text-rose-700 font-bold line-through'
                            : 'bg-stone-50 border-stone-200 text-stone-700'
                        }`}
                      >
                        Sem {ing}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Item notes */}
            <div className="space-y-1">
              <label className="text-xs font-semibold text-stone-700">Observações do Item:</label>
              <input
                type="text"
                value={itemNotes}
                onChange={(e) => setItemNotes(e.target.value)}
                placeholder="Ex: Ponto da carne, bem passado..."
                className="w-full p-2 text-xs bg-stone-50 border border-stone-200 rounded-lg focus:outline-none"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-stone-100">
              <button
                type="button"
                onClick={() => setCustomizingProduct(null)}
                className="px-3 py-2 text-xs font-semibold text-stone-600 hover:bg-stone-100 rounded-lg"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleConfirmCustomize}
                className="px-4 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-lg"
              >
                Adicionar ao Pedido
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Receipt Modal after sale */}
      <ReceiptModal
        order={lastFinishedOrder}
        settings={settings}
        onClose={() => setLastFinishedOrder(null)}
      />
    </div>
  );
};
