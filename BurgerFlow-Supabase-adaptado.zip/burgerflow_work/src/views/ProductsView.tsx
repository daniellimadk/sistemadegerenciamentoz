import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import type { Product, ProductIngredient, ProductAddOnOption } from '../types/index.ts';
import { formatCurrency } from '../utils/formatters.ts';
import {
  UtensilsCrossed,
  Plus,
  Edit2,
  Trash2,
  Copy,
  Eye,
  CheckCircle2,
  XCircle,
  Search,
  Flame,
  Clock,
  Sparkles,
  Layers,
  ChevronDown
} from 'lucide-react';

export const ProductsView: React.FC = () => {
  const {
    products,
    categories,
    inventory,
    createProduct,
    updateProduct,
    deleteProduct
  } = useApp();

  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Edit / Create modal state
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isCreating, setIsCreating] = useState(false);

  // Form State
  const [formData, setFormData] = useState<Partial<Product>>({
    code: 'PROD-' + Math.floor(100 + Math.random() * 900),
    name: '',
    description: '',
    price: 35.00,
    costPrice: 12.00,
    categoryId: categories[0]?.id || 'cat-1',
    imageUrl: '/src/assets/images/burger_artesanal_1791633585054.jpg',
    available: true,
    featured: false,
    prepTimeMinutes: 15,
    ingredients: [],
    addOns: [],
    removableIngredients: []
  });

  const filteredProducts = products.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.code.toLowerCase().includes(search.toLowerCase());
    const matchesCat = selectedCategory === 'all' || p.categoryId === selectedCategory;
    return matchesSearch && matchesCat;
  });

  const handleOpenCreate = () => {
    setFormData({
      code: 'PROD-' + Math.floor(100 + Math.random() * 900),
      name: '',
      description: '',
      price: 35.00,
      costPrice: 12.00,
      categoryId: categories[0]?.id || 'cat-1',
      imageUrl: '/src/assets/images/burger_artesanal_1791633585054.jpg',
      available: true,
      featured: false,
      prepTimeMinutes: 15,
      ingredients: [],
      addOns: [
        { id: 'add-' + Date.now(), name: 'Bacon Extra', price: 6.00 },
        { id: 'add-' + (Date.now() + 1), name: 'Cheddar Duplo', price: 5.00 }
      ],
      removableIngredients: ['Cebola', 'Picles', 'Molho']
    });
    setIsCreating(true);
    setEditingProduct(null);
  };

  const handleOpenEdit = (product: Product) => {
    setEditingProduct(product);
    setFormData({ ...product });
    setIsCreating(false);
  };

  const handleDuplicate = async (product: Product) => {
    const duplicateData: Partial<Product> = {
      ...product,
      code: product.code + '-CP',
      name: product.name + ' (Cópia)'
    };
    await createProduct(duplicateData);
  };

  const handleSaveProduct = async () => {
    if (!formData.name) return;

    if (isCreating) {
      await createProduct(formData);
    } else if (editingProduct) {
      await updateProduct(editingProduct.id, formData);
    }

    setIsCreating(false);
    setEditingProduct(null);
  };

  const calculateMargin = (price: number, cost: number) => {
    if (!price || price <= 0) return 0;
    return Math.round(((price - cost) / price) * 100);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-stone-900">
            Cardápio & Fichas Técnicas
          </h1>
          <p className="text-xs sm:text-sm text-stone-500 mt-0.5">
            Cadastre receitas, ingredientes para baixa automática de estoque e adicionais.
          </p>
        </div>

        <button
          type="button"
          onClick={handleOpenCreate}
          className="flex items-center gap-1.5 px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Cadastrar Novo Produto</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-2xs flex flex-wrap items-center gap-3">
        <div className="flex-1 min-w-[240px] relative">
          <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar por nome ou código do produto..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500"
          />
        </div>

        <div className="flex items-center gap-1.5">
          <span className="text-xs text-stone-500">Categoria:</span>
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="text-xs bg-stone-50 border border-stone-200 rounded-lg px-2.5 py-2 focus:outline-none"
          >
            <option value="all">Todas ({products.length})</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredProducts.map((product) => {
          const category = categories.find(c => c.id === product.categoryId);
          const margin = calculateMargin(product.price, product.costPrice);

          return (
            <div
              key={product.id}
              className="bg-white rounded-xl border border-stone-200 shadow-2xs overflow-hidden flex flex-col justify-between"
            >
              <div>
                <div className="relative h-44 bg-stone-100 overflow-hidden">
                  <img
                    src={product.imageUrl}
                    alt={product.name}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-2 left-2 flex gap-1">
                    <span className="bg-stone-900/80 text-white font-mono text-[10px] px-2 py-0.5 rounded-sm">
                      {product.code}
                    </span>
                    {product.featured && (
                      <span className="bg-amber-500 text-stone-950 font-bold text-[10px] px-2 py-0.5 rounded-sm flex items-center gap-0.5">
                        <Sparkles className="w-2.5 h-2.5" /> Destaque
                      </span>
                    )}
                  </div>

                  <span className={`absolute bottom-2 right-2 text-[10px] font-bold px-2 py-0.5 rounded-sm ${
                    product.available ? 'bg-emerald-600 text-white' : 'bg-rose-600 text-white'
                  }`}>
                    {product.available ? 'DISPONÍVEL' : 'ESGOTADO'}
                  </span>
                </div>

                <div className="p-4 space-y-2.5">
                  <div>
                    <span className="text-[10px] font-semibold text-stone-400 uppercase tracking-wider">
                      {category?.name || 'Geral'}
                    </span>
                    <h3 className="font-bold text-stone-900 text-sm">{product.name}</h3>
                    <p className="text-xs text-stone-500 line-clamp-2 mt-1 leading-snug">
                      {product.description}
                    </p>
                  </div>

                  {/* Financial & Margin specs */}
                  <div className="p-2.5 bg-stone-50 rounded-lg border border-stone-200 flex items-center justify-between text-xs font-mono">
                    <div>
                      <span className="text-stone-400 text-[10px] block">Venda</span>
                      <strong className="text-stone-900 text-sm">{formatCurrency(product.price)}</strong>
                    </div>
                    <div>
                      <span className="text-stone-400 text-[10px] block">Custo (CMV)</span>
                      <span className="text-stone-600">{formatCurrency(product.costPrice)}</span>
                    </div>
                    <div>
                      <span className="text-stone-400 text-[10px] block">Margem</span>
                      <span className="font-bold text-emerald-700">{margin}%</span>
                    </div>
                  </div>

                  {/* Recipe & Addons count */}
                  <div className="text-[11px] text-stone-500 flex items-center justify-between pt-1">
                    <span>Insumos da Ficha: <strong>{product.ingredients?.length || 0}</strong></span>
                    <span>Adicionais: <strong>{product.addOns?.length || 0}</strong></span>
                    <span className="flex items-center gap-0.5">
                      <Clock className="w-3 h-3 text-stone-400" /> {product.prepTimeMinutes} min
                    </span>
                  </div>
                </div>
              </div>

              {/* Action buttons */}
              <div className="p-3 bg-stone-50 border-t border-stone-200 flex items-center justify-between gap-1">
                <button
                  type="button"
                  onClick={() => updateProduct(product.id, { available: !product.available })}
                  className={`text-[11px] font-semibold px-2 py-1 rounded-md transition-colors ${
                    product.available
                      ? 'text-rose-700 hover:bg-rose-50'
                      : 'text-emerald-700 hover:bg-emerald-50'
                  }`}
                >
                  {product.available ? 'Pausar Venda' : 'Ativar Venda'}
                </button>

                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => handleDuplicate(product)}
                    title="Duplicar Produto"
                    className="p-1.5 text-stone-500 hover:text-stone-900 hover:bg-stone-200 rounded-md"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleOpenEdit(product)}
                    title="Editar Produto"
                    className="p-1.5 text-stone-500 hover:text-stone-900 hover:bg-stone-200 rounded-md"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      if (confirm(`Deseja excluir ${product.name}?`)) {
                        deleteProduct(product.id);
                      }
                    }}
                    title="Excluir Produto"
                    className="p-1.5 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded-md"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* CREATE / EDIT MODAL */}
      {(isCreating || editingProduct) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col">
            <div className="p-4 border-b border-stone-200 flex items-center justify-between bg-stone-50">
              <h3 className="font-bold text-sm text-stone-900">
                {isCreating ? 'Novo Produto no Cardápio' : `Editar: ${editingProduct?.name}`}
              </h3>
              <button
                type="button"
                onClick={() => {
                  setIsCreating(false);
                  setEditingProduct(null);
                }}
                className="text-stone-400 hover:text-stone-700"
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-stone-700">Código do Produto:</label>
                  <input
                    type="text"
                    value={formData.code}
                    onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                    className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg font-mono"
                  />
                </div>
                <div>
                  <label className="font-semibold text-stone-700">Categoria:</label>
                  <select
                    value={formData.categoryId}
                    onChange={(e) => setFormData({ ...formData, categoryId: e.target.value })}
                    className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="font-semibold text-stone-700">Nome do Produto:</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Ex: Smash Bacon Especial"
                  className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg"
                />
              </div>

              <div>
                <label className="font-semibold text-stone-700">Descrição Comercial:</label>
                <textarea
                  rows={2}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Descreva os ingredientes e detalhes para o cliente..."
                  className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="font-semibold text-stone-700">Preço de Venda (R$):</label>
                  <input
                    type="number"
                    step="0.5"
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: parseFloat(e.target.value) || 0 })}
                    className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="font-semibold text-stone-700">Custo Estimado (R$):</label>
                  <input
                    type="number"
                    step="0.5"
                    value={formData.costPrice}
                    onChange={(e) => setFormData({ ...formData, costPrice: parseFloat(e.target.value) || 0 })}
                    className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg font-mono"
                  />
                </div>
                <div>
                  <label className="font-semibold text-stone-700">Tempo de Preparo (min):</label>
                  <input
                    type="number"
                    value={formData.prepTimeMinutes}
                    onChange={(e) => setFormData({ ...formData, prepTimeMinutes: parseInt(e.target.value) || 10 })}
                    className="w-full mt-1 p-2 bg-stone-50 border border-stone-200 rounded-lg"
                  />
                </div>
              </div>

              {/* Ficha técnica: Vincular ingredientes do estoque */}
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-stone-900">
                    Ficha Técnica (Insumos consumidos por unidade)
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      if (inventory.length === 0) return;
                      const first = inventory[0];
                      const current = formData.ingredients || [];
                      setFormData({
                        ...formData,
                        ingredients: [
                          ...current,
                          { inventoryItemId: first.id, name: first.name, quantity: 1, unit: first.unit }
                        ]
                      });
                    }}
                    className="text-[11px] font-bold text-amber-700 hover:underline flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" /> Adicionar Insumo
                  </button>
                </div>

                <div className="space-y-1.5">
                  {(formData.ingredients || []).length === 0 ? (
                    <div className="text-stone-400 text-xs italic">Nenhum insumo configurado na ficha ainda.</div>
                  ) : (
                    formData.ingredients?.map((ing, idx) => (
                      <div key={idx} className="flex items-center gap-2 bg-white p-2 rounded-md border border-stone-200">
                        <select
                          value={ing.inventoryItemId}
                          onChange={(e) => {
                            const inv = inventory.find(i => i.id === e.target.value);
                            const updated = [...(formData.ingredients || [])];
                            if (inv) {
                              updated[idx] = { ...updated[idx], inventoryItemId: inv.id, name: inv.name, unit: inv.unit };
                              setFormData({ ...formData, ingredients: updated });
                            }
                          }}
                          className="flex-1 p-1 bg-stone-50 border border-stone-200 rounded text-xs"
                        >
                          {inventory.map(i => (
                            <option key={i.id} value={i.id}>{i.name} ({i.unit})</option>
                          ))}
                        </select>
                        <input
                          type="number"
                          step="0.01"
                          value={ing.quantity}
                          onChange={(e) => {
                            const updated = [...(formData.ingredients || [])];
                            updated[idx].quantity = parseFloat(e.target.value) || 0;
                            setFormData({ ...formData, ingredients: updated });
                          }}
                          className="w-20 p-1 bg-stone-50 border border-stone-200 rounded text-xs font-mono"
                        />
                        <span className="text-[11px] text-stone-500 w-8">{ing.unit}</span>
                        <button
                          type="button"
                          onClick={() => {
                            const updated = [...(formData.ingredients || [])];
                            updated.splice(idx, 1);
                            setFormData({ ...formData, ingredients: updated });
                          }}
                          className="text-rose-500 hover:text-rose-700 p-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Toggles */}
              <div className="flex items-center gap-6 pt-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.available}
                    onChange={(e) => setFormData({ ...formData, available: e.target.checked })}
                    className="rounded text-amber-600 focus:ring-amber-500"
                  />
                  <span className="font-semibold text-stone-800">Disponível para venda imediata</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.featured}
                    onChange={(e) => setFormData({ ...formData, featured: e.target.checked })}
                    className="rounded text-amber-600 focus:ring-amber-500"
                  />
                  <span className="font-semibold text-stone-800">Destaque promocional no cardápio</span>
                </label>
              </div>
            </div>

            <div className="p-4 border-t border-stone-200 bg-stone-50 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => {
                  setIsCreating(false);
                  setEditingProduct(null);
                }}
                className="px-4 py-2 text-xs font-medium text-stone-600 hover:bg-stone-100 rounded-lg"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleSaveProduct}
                className="px-5 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-lg"
              >
                Gravar Produto
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
