export type OrderStatus =
  | 'recebido'
  | 'aguardando_confirmacao'
  | 'confirmado'
  | 'em_preparacao'
  | 'pronto'
  | 'saiu_entrega'
  | 'entregue'
  | 'cancelado';

export type OrderType = 'balcao' | 'mesa' | 'retirada' | 'delivery';

export type PaymentMethod =
  | 'pix'
  | 'dinheiro'
  | 'cartao_credito'
  | 'cartao_debito'
  | 'vale_refeicao';

export type PaymentStatus = 'pendente' | 'pago' | 'estornado';

export interface OrderItemAddon {
  id: string;
  name: string;
  price: number;
}

export interface OrderItem {
  id: string;
  productId: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  addOns?: OrderItemAddon[];
  removedIngredients?: string[];
  notes?: string;
  totalPrice: number;
}

export interface OrderStatusHistoryItem {
  status: OrderStatus;
  timestamp: string;
  updatedBy: string;
  note?: string;
}

export interface CommunicationLogItem {
  id: string;
  channel: 'app' | 'whatsapp' | 'sms' | 'push';
  message: string;
  status: 'sent' | 'pending' | 'failed';
  timestamp: string;
}

export interface Order {
  id: string;
  orderNumber: number;
  customerName: string;
  customerPhone: string;
  customerAddress?: {
    street: string;
    number: string;
    neighborhood: string;
    complement?: string;
    reference?: string;
    city?: string;
  };
  orderType: OrderType;
  tableNumber?: string;
  status: OrderStatus;
  cancellationReason?: string;
  items: OrderItem[];
  subtotal: number;
  deliveryFee: number;
  discount: number;
  couponCode?: string;
  total: number;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  changeFor?: number;
  customerNotes?: string;
  estimatedPrepMinutes: number;
  courierId?: string;
  courierName?: string;
  createdAt: string;
  updatedAt: string;
  statusHistory: OrderStatusHistoryItem[];
  communicationLog: CommunicationLogItem[];
  stockStatus: 'none' | 'reserved' | 'deducted' | 'returned';
}

export interface ProductIngredient {
  inventoryItemId: string;
  name: string;
  quantity: number;
  unit: string;
}

export interface ProductAddOnOption {
  id: string;
  name: string;
  price: number;
  maxQuantity?: number;
}

export interface Product {
  id: string;
  code: string;
  name: string;
  description: string;
  price: number;
  costPrice: number;
  categoryId: string;
  imageUrl: string;
  available: boolean;
  featured: boolean;
  prepTimeMinutes: number;
  ingredients: ProductIngredient[];
  addOns: ProductAddOnOption[];
  removableIngredients: string[];
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  order: number;
  active: boolean;
  iconName?: string;
}

export type InventoryMovementType =
  | 'entrada'
  | 'saida_manual'
  | 'consumo_producao'
  | 'perda_desperdicio'
  | 'vencido'
  | 'ajuste_inventario'
  | 'devolucao_cancelamento'
  | 'compra';

export interface InventoryMovement {
  id: string;
  itemId: string;
  itemName: string;
  type: InventoryMovementType;
  quantity: number;
  unitCost: number;
  date: string;
  reason: string;
  userId: string;
  orderId?: string;
}

export interface InventoryItem {
  id: string;
  code: string;
  name: string;
  category: string;
  unit: 'un' | 'kg' | 'g' | 'l' | 'ml';
  currentQuantity: number;
  reservedQuantity: number;
  minQuantity: number;
  unitCost: number;
  supplierId?: string;
  supplierName?: string;
  expirationDate?: string;
  lotNumber?: string;
  storageLocation?: string;
}

export interface CashRegister {
  id: string;
  openedAt: string;
  closedAt?: string;
  openedBy: string;
  closedBy?: string;
  initialCash: number;
  currentCash: number;
  salesCash: number;
  salesCard: number;
  salesPix: number;
  totalSales: number;
  sangrias: number;
  suprimentos: number;
  finalCashCounted?: number;
  difference?: number;
  status: 'open' | 'closed';
  notes?: string;
}

export interface CashMovement {
  id: string;
  cashRegisterId: string;
  type: 'suprimento' | 'sangria';
  amount: number;
  reason: string;
  timestamp: string;
  operator: string;
}

export interface Expense {
  id: string;
  description: string;
  category: 'fixa' | 'variavel' | 'ingredientes' | 'taxas' | 'pessoal' | 'outros';
  amount: number;
  dueDate: string;
  paidDate?: string;
  status: 'pago' | 'pendente';
  supplierId?: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email?: string;
  addresses: Array<{
    street: string;
    number: string;
    neighborhood: string;
    complement?: string;
    reference?: string;
  }>;
  ordersCount: number;
  totalSpent: number;
  points: number;
  createdAt: string;
  lastOrderDate?: string;
}

export interface Coupon {
  id: string;
  code: string;
  discountType: 'fixed' | 'percentage';
  value: number;
  minOrderValue: number;
  active: boolean;
  validUntil: string;
  usageCount: number;
}

export interface Courier {
  id: string;
  name: string;
  phone: string;
  vehicle: 'moto' | 'bicicleta' | 'carro';
  plate?: string;
  active: boolean;
  currentDeliveriesCount: number;
}

export interface Supplier {
  id: string;
  name: string;
  contactPerson: string;
  phone: string;
  email: string;
  cnpj?: string;
  itemsSupplied?: string[];
}

export type UserRole = 'admin' | 'gerente' | 'atendente' | 'cozinha' | 'caixa' | 'entregador';

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  pin: string;
  active: boolean;
}

export interface DeliveryNeighborhood {
  name: string;
  fee: number;
  estimatedMinutes: number;
}

export interface RestaurantSettings {
  restaurantName: string;
  tradeName: string;
  cnpj: string;
  phone: string;
  whatsapp: string;
  address: string;
  city: string;
  state: string;
  isOpen: boolean;
  openingHoursDescription: string;
  standardDeliveryFee: number;
  freeDeliveryThreshold: number;
  minOrderValue: number;
  averagePrepTimeMinutes: number;
  deliveryNeighborhoods: DeliveryNeighborhood[];
  automatedMessages: Record<OrderStatus, string>;
  soundAlertsEnabled: boolean;
  soundVolume: number;
  printerWidth: '80mm' | '58mm';
  autoAcceptOrders: boolean;
  kitchenStations: string[];
}

export interface SystemNotification {
  id: string;
  type: 'novo_pedido' | 'estoque_baixo' | 'pedido_cancelado' | 'pagamento' | 'alerta_cozinha' | 'caixa';
  title: string;
  message: string;
  orderId?: string;
  timestamp: string;
  read: boolean;
}

export interface SystemAuditLog {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  action: string;
  details: string;
  category: 'pedido' | 'estoque' | 'caixa' | 'produto' | 'config';
}
